import { useEffect, useState } from 'react';
import { LuVolume2, LuVolumeX, LuBookOpen, LuSettings2, LuRadio, LuUsers, LuList, LuShieldCheck, LuMessageCircle, LuLogOut } from 'react-icons/lu';
import { useRoom, useHostAway } from './Room';
import { takeHost } from '../lib/engine';
import { fmt, squadOf, overseasCount, MAX_OVERSEAS, MIN_SQUAD, arr } from '../lib/rules';
import { Paddle, Logo } from './ui';
import Stage from './Stage';
import { TeamsPanel, FeedPanel, PoolPanel, SquadPanel, RivalModal, PlayerInfoModal, XIBuilder } from './Panels';
import Chat from './Chat';
import HostPanel from './HostPanel';
import Nominate from './Nominate';
import RulesModal from './Rules';
import { isMuted, setMuted, onMute } from '../lib/sound';
import { MODE } from '../lib/db';

function useMute() {
  const [m, setM] = useState(isMuted());
  useEffect(() => onMute(setM), []);
  useEffect(() => {
    const k = (e) => { if (e.key.toLowerCase() === 'm' && !['INPUT', 'TEXTAREA', 'SELECT'].includes(e.target.tagName)) setMuted(!isMuted()); };
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  }, []);
  return [m, () => setMuted(!m)];
}

function SyncStatus() {
  const { connected, latency } = useRoom();
  const good = connected && latency != null && latency < 400;
  const color = !connected ? 'bg-bad' : good ? 'bg-good' : 'bg-warn';
  return (
    <span className="flex items-center gap-1.5 text-[12px] text-fg-3" title={MODE === 'local' ? 'Local demo mode' : 'Sync with Firebase'}>
      <span className={`size-2 rounded-full ${color}`} />
      <span className="num hidden font-mono sm:inline">{!connected ? 'Offline' : MODE === 'local' ? 'Local' : latency != null ? `${latency} ms` : '…'}</span>
    </span>
  );
}

function PurseBar() {
  const { S, settings, myTeam } = useRoom();
  const tm = S.teams?.[myTeam];
  if (!tm) return null;
  const n = squadOf(tm).length;
  const os = overseasCount(tm);
  const open = Math.max(1, settings.maxSquad - n);
  const items = [
    ['Purse', fmt(tm.purse), 'text-brass'],
    ['Squad', `${n}/${settings.maxSquad}`, n < MIN_SQUAD ? '' : 'text-good'],
    ['Overseas', `${os}/${MAX_OVERSEAS}`, os >= MAX_OVERSEAS - 1 ? 'text-warn' : ''],
    ...(settings.rtm ? [['RTMs', tm.rtm || 0, '']] : []),
    ['Per open slot', fmt(Math.floor(tm.purse / open)), ''],
  ];
  return (
    <div className="border-b border-line bg-ink-950/60">
      <div className="no-scrollbar mx-auto flex h-12 max-w-[1600px] items-center gap-5 overflow-x-auto px-4 sm:gap-8 sm:px-6">
        <Paddle team={myTeam} size={24} />
        {items.map(([k, v, c]) => (
          <div key={k} className="flex shrink-0 items-baseline gap-2">
            <span className="text-[12px] text-fg-3">{k}</span>
            <span className={`num font-display text-[18px] font-semibold ${c}`}>{v}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function useDesktop() {
  const q = '(min-width: 1024px)';
  const [d, setD] = useState(() => matchMedia(q).matches);
  useEffect(() => { const m = matchMedia(q); const f = () => setD(m.matches); m.addEventListener('change', f); return () => m.removeEventListener('change', f); }, []);
  return d;
}

const TABS = [
  ['live', 'Live', LuRadio], ['teams', 'Teams', LuUsers], ['pool', 'Players', LuList], ['squad', 'Squad', LuShieldCheck], ['chat', 'Chat', LuMessageCircle],
];

export default function Auction() {
  const { S, isHost, myTeam, code, onExit } = useRoom();
  const [muted, toggleMute] = useMute();
  const [tab, setTab] = useState('live');
  const [side, setSide] = useState('feed');
  const [host, setHost] = useState(false);
  const [rules, setRules] = useState(false);
  const [rival, setRival] = useState(null);
  const [info, setInfo] = useState(null);
  const [xi, setXi] = useState(false);
  const hostAway = useHostAway();
  const desktop = useDesktop();
  const L = S.live;
  const list = arr(S.queue?.list);
  const round = S.queue?.round;
  const progress = L && list.length ? `${round === 'main' ? 'Player' : round === 'reentry' ? 'Re-entry' : 'Accelerated'} ${Math.min((L.idx ?? 0) + 1, list.length)} of ${list.length}` : '';

  const sideTabs = [['feed', 'Feed'], ['chat', 'Chat'], ['pool', 'Players'], ['squad', 'My squad']];
  const panel = (k) => ({
    feed: <FeedPanel />,
    chat: null,
    pool: <PoolPanel onPlayerInfo={setInfo} />,
    squad: <SquadPanel team={myTeam} onXI={() => setXi(true)} />,
    teams: <TeamsPanel onRival={setRival} />,
  }[k]);

  return (
    <div className="flex min-h-dvh flex-col lg:h-dvh">
      <header className="z-30 border-b border-line bg-ink-900/95 backdrop-blur">
        <div className="mx-auto flex h-14 max-w-[1600px] items-center gap-3 px-4 sm:px-6">
          <span className="hidden sm:block"><Logo small /></span>
          <span className="sm:hidden"><Paddle team={myTeam} size={24} /></span>
          <div className="min-w-0 flex-1 sm:ml-4">
            <div className="truncate text-[13px] font-medium">{L?.set || 'Auction'}</div>
            <div className="num truncate font-mono text-[11px] text-fg-3">{progress} · Room {code}</div>
          </div>
          <SyncStatus />
          <button className="btn btn-ghost btn-sm px-2" onClick={toggleMute} aria-label={muted ? 'Unmute' : 'Mute'} title="Mute (M)">{muted ? <LuVolumeX size={18} /> : <LuVolume2 size={18} />}</button>
          <button className="btn btn-ghost btn-sm px-2" onClick={() => setRules(true)} aria-label="Rules"><LuBookOpen size={18} /></button>
          {isHost && <button className="btn btn-sm" onClick={() => setHost(true)}><LuSettings2 size={16} /><span className="hidden sm:inline">Auctioneer</span></button>}
          {!isHost && hostAway && <button className="btn btn-sm" onClick={() => takeHost(code)}>Take over host</button>}
          <button className="btn btn-ghost btn-sm hidden px-2 sm:inline-flex" onClick={onExit} aria-label="Leave room" title="Leave (you can rejoin with the link)"><LuLogOut size={18} /></button>
        </div>
        {list.length > 0 && <div className="h-0.5 bg-ink-800"><div className="h-full bg-brass/70 transition-[width] duration-500" style={{ width: `${Math.min(100, (((L?.idx ?? 0) + (L?.stage === 'result' ? 1 : 0)) / list.length) * 100)}%` }} /></div>}
      </header>
      <PurseBar />

      {/* Desktop */}
      {desktop && <div className="mx-auto grid min-h-0 w-full max-w-[1600px] flex-1 grid-cols-[280px_minmax(0,1fr)_360px] gap-5 px-6 py-5">
        <aside className="scroll-y min-h-0"><TeamsPanel onRival={setRival} /></aside>
        <main className="scroll-y min-h-0 pr-1"><div className="mx-auto max-w-[720px]"><Stage onPlayerInfo={setInfo} /></div></main>
        <aside className="panel flex min-h-0 flex-col overflow-hidden">
          <div className="flex h-12 shrink-0 items-center gap-1 border-b border-line px-2">
            {sideTabs.map(([k, l]) => <button key={k} onClick={() => setSide(k)} className={`h-8 rounded-md px-3 text-[13px] transition-colors ${side === k ? 'bg-ink-700 text-fg' : 'text-fg-2 hover:text-fg'}`}>{l}</button>)}
          </div>
          {side === 'chat' ? <Chat className="flex-1" /> : <div className="scroll-y min-h-0 flex-1 p-4">{panel(side)}</div>}
        </aside>
      </div>}

      {/* Mobile */}
      {!desktop && <><div className="flex-1 pb-[72px] lg:hidden">
        {tab === 'live' && (
          <div className="px-4 py-4">
            <Stage onPlayerInfo={setInfo} compactFeed={<div className="mt-5"><div className="label mb-1">Latest</div><FeedPanel limit={5} /></div>} />
          </div>
        )}
        {tab === 'chat' && <Chat className="h-[calc(100dvh-56px-48px-72px)]" />}
        {['teams', 'pool', 'squad'].includes(tab) && <div className="px-4 py-4">{tab === 'teams' ? <><TeamsPanel onRival={setRival} /><div className="mt-6"><FeedPanel /></div></> : panel(tab)}</div>}
      </div>
      <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-ink-900/95 backdrop-blur safe-bottom lg:hidden">
        <div className="grid h-16 grid-cols-5">
          {TABS.map(([k, l, Icon]) => (
            <button key={k} onClick={() => setTab(k)} className={`flex flex-col items-center justify-center gap-1 text-[11px] transition-colors ${tab === k ? 'text-fg' : 'text-fg-3'}`} aria-current={tab === k}>
              <Icon size={18} />{l}
              {k === 'live' && L?.stage === 'bidding' && tab !== 'live' && <span className="absolute mt-[-28px] ml-6 size-1.5 rounded-full bg-brass" />}
            </button>
          ))}
        </div>
      </nav></>}

      <HostPanel open={host} onClose={() => setHost(false)} />
      <RulesModal open={rules} onClose={() => setRules(false)} />
      <RivalModal team={rival} onClose={() => setRival(null)} />
      <PlayerInfoModal p={info} onClose={() => setInfo(null)} />
      {xi && <XIBuilder open onClose={() => setXi(false)} />}
      {S.meta?.phase === 'nominate' && <Nominate />}
    </div>
  );
}

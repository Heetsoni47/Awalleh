import { useEffect, useRef, useState } from 'react';
import { LuSend } from 'react-icons/lu';
import { useRoom } from './Room';
import { sendChat } from '../lib/engine';
import { Paddle, Avatar, Empty } from './ui';
import { TEAMS } from '../lib/rules';

const TAUNTS = ['Inflating the price', 'Take him', 'Purse empty?', 'Steal of the night', 'Overpaid', 'Not blinking', 'Sold to the man in yellow', 'Calm down'];

export default function Chat({ className = '', taunts = true }) {
  const { code, S, chat } = useRoom();
  const [text, setText] = useState('');
  const box = useRef(null);
  const msgs = Object.entries(chat || {}).sort(([a], [b]) => (a < b ? -1 : 1)).map(([k, v]) => ({ k, ...v }));
  useEffect(() => { box.current && (box.current.scrollTop = box.current.scrollHeight); }, [msgs.length]);
  const send = (t) => { const v = (t ?? text).trim(); if (!v) return; sendChat(code, S, v); setText(''); };

  return (
    <div className={`flex min-h-0 flex-col ${className}`}>
      <div ref={box} className="scroll-y min-h-0 flex-1 space-y-3 px-4 py-3">
        {!msgs.length && <Empty>No messages yet. Start the trash talk.</Empty>}
        {msgs.map((m) => {
          const member = S.members?.[m.uid];
          return (
            <div key={m.k} className="flex gap-2.5">
              {m.team ? <Paddle team={m.team} size={22} /> : <Avatar name={m.name} color={member?.color} size={22} />}
              <div className="min-w-0">
                <div className="text-[12px] font-medium" style={{ color: m.team ? TEAMS[m.team].ink : 'var(--color-fg-2)' }}>
                  {m.name}{m.team ? <span className="font-normal text-fg-3"> · {m.team}</span> : null}
                </div>
                <div className="break-words text-[14px] leading-5 text-fg">{m.text}</div>
              </div>
            </div>
          );
        })}
      </div>
      {taunts && (
        <div className="no-scrollbar flex gap-1.5 overflow-x-auto border-t border-line px-4 py-2">
          {TAUNTS.map((t) => <button key={t} className="chip h-7 shrink-0 px-2.5 text-[12px] transition-colors hover:bg-ink-700 hover:text-fg" onClick={() => send(t)}>{t}</button>)}
        </div>
      )}
      <form className="flex gap-2 border-t border-line p-3" onSubmit={(e) => { e.preventDefault(); send(); }}>
        <input className="field h-10" value={text} onChange={(e) => setText(e.target.value)} placeholder="Message" maxLength={240} aria-label="Chat message" />
        <button className="btn h-10 px-3" aria-label="Send"><LuSend size={16} /></button>
      </form>
    </div>
  );
}

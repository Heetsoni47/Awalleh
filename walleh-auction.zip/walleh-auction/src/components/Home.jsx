import { useState } from 'react';
import { LuArrowRight, LuBookOpen } from 'react-icons/lu';
import { createRoom, joinRoom } from '../lib/engine';
import { PLAYERS } from '../data/playersData';
import { Logo, Paddle } from './ui';
import Spotlight from './Spotlight';
import RulesModal from './Rules';
import { TEAM_IDS, fmt } from '../lib/rules';

const demo = PLAYERS.find((p) => p.name === 'Rishabh Pant');

export default function Home({ initialCode, onEnter, mode }) {
  const [name, setName] = useState(localStorage.getItem('walleh-name') || '');
  const [code, setCode] = useState(initialCode || '');
  const [tab, setTab] = useState(initialCode ? 'join' : 'create');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [rules, setRules] = useState(false);

  const go = async (e) => {
    e.preventDefault();
    if (!name.trim()) return setErr('Enter your name');
    setBusy(true); setErr('');
    try {
      if (tab === 'create') onEnter(await createRoom(name), name.trim());
      else {
        const c = code.trim().toUpperCase();
        if (c.length !== 6) throw new Error('Room codes have 6 characters');
        await joinRoom(c, name);
        onEnter(c, name.trim());
      }
    } catch (ex) { setErr(ex.message); setBusy(false); }
  };

  return (
    <div className="min-h-dvh">
      <header className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5 sm:px-8">
        <Logo />
        <button className="btn btn-ghost btn-sm" onClick={() => setRules(true)}><LuBookOpen size={16} /> Rules</button>
      </header>

      <main className="mx-auto grid max-w-6xl items-center gap-12 px-5 pb-16 pt-8 sm:px-8 lg:min-h-[calc(100dvh-64px)] lg:grid-cols-[1fr_1.05fr] lg:pb-24 lg:pt-0">
        <section className="animate-rise">
          <h1 className="font-display text-[44px] font-semibold leading-[1] tracking-[-0.02em] sm:text-[64px]">
            Your own IPL mega auction, live with your mates
          </h1>
          <p className="mt-5 max-w-[34rem] text-[17px] leading-7 text-fg-2">
            Create a room, send the link, and bid live for 264 players with ₹120 Cr purses, RTM cards and a ticking gavel. Works on any phone or laptop.
          </p>

          <form onSubmit={go} className="panel mt-8 max-w-md p-5">
            <div className="mb-4 grid grid-cols-2 rounded-[10px] border border-line bg-ink-900 p-1">
              {[['create', 'Create room'], ['join', 'Join room']].map(([k, l]) => (
                <button type="button" key={k} onClick={() => { setTab(k); setErr(''); }}
                  className={`h-9 rounded-md text-[14px] transition-colors ${tab === k ? 'bg-ink-700 text-fg' : 'text-fg-2 hover:text-fg'}`}>{l}</button>
              ))}
            </div>
            <label className="label" htmlFor="nm">Your name</label>
            <input id="nm" className="field mt-1" maxLength={18} value={name} onChange={(e) => setName(e.target.value)} placeholder="Rohan" autoComplete="nickname" />
            {tab === 'join' && (
              <>
                <label className="label mt-4 block" htmlFor="cd">Room code</label>
                <input id="cd" className="field mt-1 font-mono uppercase tracking-[0.2em]" maxLength={6} value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} placeholder="K7M2QX" autoCapitalize="characters" />
              </>
            )}
            {err && <p className="mt-3 text-[13px] text-bad">{err}</p>}
            <button className="btn btn-primary mt-5 h-12 w-full text-[15px]" disabled={busy}>
              {tab === 'create' ? 'Create auction room' : 'Join auction'} <LuArrowRight size={18} />
            </button>
            <p className="mt-3 text-[12px] text-fg-3">No sign-up. Pick a franchise in the lobby, or just watch.</p>
          </form>
          {mode === 'local' && (
            <p className="mt-4 max-w-md text-[12px] leading-4 text-warn/90">
              Demo mode: Firebase isn't connected yet, so rooms only work between tabs of this browser. Add your keys to firebase-config.js to play with friends.
            </p>
          )}
        </section>

        <section className="relative mx-auto w-full max-w-[520px] animate-rise lg:mx-0" aria-label="Preview of the auction table">
          <div className="mb-3 flex items-center justify-between text-[13px] text-fg-2">
            <span>Marquee set 1 · Player 3 of 264</span>
            <span className="num font-mono text-fg-3">00:06</span>
          </div>
          <Spotlight p={demo} lead="LSG" stamp="sold" soldTo="LSG" soldPrice={2700}>
            <div className="mt-5 flex items-center justify-between rounded-xl border border-line bg-ink-900/70 p-3">
              <div className="flex items-center gap-3">
                <Paddle team="LSG" size={36} />
                <div>
                  <div className="label">Highest bid</div>
                  <div className="num font-display text-[28px] font-semibold leading-none">{fmt(2700)}</div>
                </div>
              </div>
              <div className="flex -space-x-1.5">
                {['DC', 'RCB', 'SRH', 'LSG'].map((t) => <Paddle key={t} team={t} size={24} />)}
              </div>
            </div>
          </Spotlight>
          <div className="mt-4 flex flex-wrap gap-2">
            {TEAM_IDS.map((t) => <Paddle key={t} team={t} size={28} />)}
          </div>
        </section>
      </main>
      <RulesModal open={rules} onClose={() => setRules(false)} />
    </div>
  );
}

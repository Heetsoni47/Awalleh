import { useState } from 'react';
import { LuPause, LuPlay, LuUndo2, LuGavel, LuX, LuSkipForward, LuZap, LuRepeat, LuFastForward, LuFlag, LuCrown, LuUserX } from 'react-icons/lu';
import { useRoom } from './Room';
import * as E from '../lib/engine';
import { SET_ORDER, arr } from '../lib/rules';
import { PLAYER_MAP } from '../data/playersData';
import { Modal, Avatar, PresenceDot, useToast } from './ui';

export default function HostPanel({ open, onClose }) {
  const { code, S, settings, uid } = useRoom();
  const toast = useToast();
  const [breakMsg, setBreakMsg] = useState('');
  if (!open) return null;
  const L = S.live || {};
  const active = ['bidding', 'rtm', 'counter', 'match'].includes(L.stage);
  const list = arr(S.queue?.list);
  const remainingSets = [...new Set(list.slice(L.idx ?? 0).map((pid) => PLAYER_MAP[pid].set))];
  const unsold = Object.values(S.players || {}).filter((v) => v.status === 'unsold').length;
  const act = (fn, msg) => async () => { try { await fn(); if (msg) toast(msg); } catch (e) { toast(e.message); } };

  return (
    <Modal open onClose={onClose} title="Auctioneer controls" wide>
      <div className="grid gap-5 md:grid-cols-2">
        <section>
          <h3 className="label mb-2">Current lot</h3>
          <div className="grid grid-cols-2 gap-2">
            {L.paused
              ? <button className="btn" onClick={act(() => E.resume(code))}><LuPlay size={16} /> Resume</button>
              : <button className="btn" onClick={act(() => E.pause(code, breakMsg))} disabled={!S.live}><LuPause size={16} /> Pause</button>}
            <button className="btn" disabled={L.stage !== 'bidding' || !arr(L.history).length} onClick={act(() => E.undoBid(code, S), 'Last bid undone')}><LuUndo2 size={16} /> Undo last bid</button>
            <button className="btn" disabled={!active || !L.team} onClick={act(() => E.forceSold(code, S))}><LuGavel size={16} /> Force sold</button>
            <button className="btn" disabled={!active} onClick={act(() => E.forceUnsold(code, S))}><LuX size={16} /> Force unsold</button>
          </div>
          <input className="field mt-2 h-10" placeholder="Break message, e.g. Chai break, back in 5" value={breakMsg} onChange={(e) => setBreakMsg(e.target.value)} />

          <h3 className="label mb-2 mt-5">Flow</h3>
          <div className="grid grid-cols-2 gap-2">
            <button className="btn" disabled={!!L.team || L.stage === 'complete' || S.queue?.round !== 'main'} onClick={act(() => E.skipSet(code, S), 'Set skipped')}><LuSkipForward size={16} /> Skip set</button>
            <button className="btn" disabled={L.stage === 'complete' && !list.length} onClick={act(() => confirm('Quick-sim every remaining player? Bots will decide all the sales.') && E.quickSim(code, S))}><LuFastForward size={16} /> Quick-sim rest</button>
            <button className="btn" onClick={act(() => E.openNominations(code, S))}><LuZap size={16} /> Accelerated round</button>
            <button className="btn" disabled={!settings.reentry || !unsold || L.stage !== 'complete'} onClick={act(() => E.startReentry(code, S))}><LuRepeat size={16} /> Re-entry ({unsold})</button>
          </div>
          {S.queue?.round === 'main' && remainingSets.length > 1 && (
            <div className="mt-2">
              <select className="field h-10" value="" disabled={!!L.team} onChange={(e) => e.target.value && E.jumpToSet(code, S, e.target.value)} aria-label="Jump to set">
                <option value="">Jump to set</option>
                {SET_ORDER.filter((s) => remainingSets.includes(s)).map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
          )}
          <button className="btn btn-primary mt-3 w-full" onClick={act(() => confirm('Finish the auction and show results to everyone?') && E.finishAuction(code, S))}><LuFlag size={16} /> Finish auction</button>
        </section>

        <section>
          <h3 className="label mb-2">Managers</h3>
          <ul className="space-y-1">
            {Object.entries(S.members || {}).map(([u, m]) => (
              <li key={u} className="flex h-11 items-center gap-3 rounded-lg px-2 hover:bg-ink-800">
                <Avatar name={m.name} color={m.color} size={26} />
                <span className="min-w-0 flex-1 truncate text-[14px]">{m.name} <span className="text-fg-3">{m.team || (m.spectator ? 'watching' : '')}</span></span>
                <PresenceDot m={m} />
                {u !== uid && (
                  <>
                    <button className="btn btn-ghost btn-sm px-1.5" title="Make host" onClick={act(() => E.transferHost(code, u), `${m.name} is now the host`)}><LuCrown size={16} /></button>
                    <button className="btn btn-ghost btn-sm px-1.5" title="Remove" onClick={act(() => confirm(`Remove ${m.name}? An AI bot takes over their team.`) && E.kick(code, S, u))}><LuUserX size={16} /></button>
                  </>
                )}
              </li>
            ))}
          </ul>
          <p className="mt-3 text-[12px] leading-4 text-fg-3">Keep this tab open: the host's browser runs the clock and the AI bots. If you leave, anyone can take over as host.</p>
        </section>
      </div>
    </Modal>
  );
}

import { useState } from 'react';
import { LuCopy, LuShare2, LuBookOpen, LuLogOut, LuCrown, LuUserX, LuEye, LuCheck, LuBot } from 'react-icons/lu';
import { useRoom, useHostAway } from './Room';
import { claimTeam, becomeSpectator, setReady, updateSettings, startAuction, kick, transferHost, leaveRoom, takeHost } from '../lib/engine';
import { TEAMS, TEAM_IDS } from '../lib/rules';
import { Paddle, Avatar, PresenceDot, Seg, Toggle, Logo, useToast } from './ui';
import Chat from './Chat';
import RulesModal from './Rules';

export function inviteLink(code) { return `${location.origin}${location.pathname}?room=${code}`; }

export default function Lobby() {
  const { code, S, settings, me, isHost, uid, onExit } = useRoom();
  const toast = useToast();
  const [rules, setRules] = useState(false);
  const [starting, setStarting] = useState(false);
  const hostAway = useHostAway();
  const members = Object.entries(S.members || {}).sort(([, a], [, b]) => (a.joinedAt || 0) - (b.joinedAt || 0));
  const owner = (t) => { const u = S.claims?.[t]; return u && S.members?.[u] ? [u, S.members[u]] : null; };
  const humanTeams = TEAM_IDS.filter((t) => owner(t)).length;
  const totalTeams = settings.bots ? Math.max(humanTeams, settings.teamCount) : humanTeams;

  const copy = async () => {
    try { await navigator.clipboard.writeText(inviteLink(code)); toast('Invite link copied'); } catch { toast(inviteLink(code)); }
  };
  const share = async () => {
    const data = { title: 'A Walleh Auction', text: `Join my IPL auction room ${code}`, url: inviteLink(code) };
    if (navigator.share) { try { await navigator.share(data); } catch {} } else copy();
  };
  const start = async () => {
    setStarting(true);
    try { await startAuction(code, S); } catch (e) { toast(e.message); setStarting(false); }
  };
  const set = (k, v) => updateSettings(code, { [k]: v });

  return (
    <div className="min-h-dvh">
      <header className="sticky top-0 z-30 border-b border-line bg-ink-900/90 backdrop-blur">
        <div className="mx-auto flex h-14 max-w-6xl items-center justify-between gap-3 px-4 sm:px-6">
          <Logo small />
          <div className="flex items-center gap-1">
            <button className="btn btn-ghost btn-sm" onClick={() => setRules(true)}><LuBookOpen size={16} /><span className="hidden sm:inline">Rules</span></button>
            <button className="btn btn-ghost btn-sm" onClick={async () => { await leaveRoom(code, S); onExit(); }}><LuLogOut size={16} /><span className="hidden sm:inline">Leave</span></button>
          </div>
        </div>
      </header>

      <main className="mx-auto grid max-w-6xl gap-5 px-4 py-5 sm:px-6 lg:grid-cols-[1fr_360px] lg:py-8">
        <div className="space-y-5">
          {/* Invite */}
          <section className="panel flex flex-col gap-4 p-5 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <div className="label">Room code</div>
              <div className="num mt-1 font-mono text-[32px] font-medium leading-none tracking-[0.18em]">{code}</div>
              <p className="mt-2 text-[13px] text-fg-2">Send the link. Friends type their name and they're in.</p>
            </div>
            <div className="flex gap-2">
              <button className="btn" onClick={copy}><LuCopy size={16} /> Copy link</button>
              <button className="btn" onClick={share}><LuShare2 size={16} /> Share</button>
            </div>
          </section>

          {/* Franchises */}
          <section className="panel p-5">
            <div className="mb-4 flex items-end justify-between gap-3">
              <div>
                <h2 className="text-[15px] font-medium">Pick your paddle</h2>
                <p className="text-[13px] text-fg-2">{humanTeams} taken · {settings.bots ? `${Math.max(0, totalTeams - humanTeams)} AI bots will join at the start` : 'AI bots off'}</p>
              </div>
              <button className={`btn btn-sm ${me?.spectator ? 'border-brass/60 text-brass' : ''}`} onClick={() => becomeSpectator(code, S)}><LuEye size={16} /> Watch only</button>
            </div>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-5">
              {TEAM_IDS.map((t) => {
                const o = owner(t);
                const mine = o?.[0] === uid;
                return (
                  <button key={t} disabled={!!o && !mine} onClick={() => claimTeam(code, S, t).then((ok) => !ok && toast('Someone just took that one'))}
                    className={`group flex flex-col items-start gap-3 rounded-xl border p-3 text-left transition-colors ${mine ? 'border-brass bg-ink-800' : o ? 'border-line bg-ink-900 opacity-80' : 'border-line bg-ink-900 hover:border-line-2 hover:bg-ink-800'}`}>
                    <Paddle team={t} size={36} />
                    <div className="min-w-0">
                      <div className="truncate text-[13px] font-medium">{TEAMS[t].name}</div>
                      <div className={`truncate text-[12px] ${mine ? 'text-brass' : o ? 'text-fg-2' : 'text-fg-3'}`}>{mine ? 'You' : o ? o[1].name : 'Available'}</div>
                    </div>
                  </button>
                );
              })}
            </div>
          </section>

          {/* Settings */}
          <section className="panel p-5">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-[15px] font-medium">Auction settings</h2>
              {!isHost && <span className="text-[12px] text-fg-3">Only the host can change these</span>}
            </div>
            <div className="divide-y divide-line">
              <SettingRow label="Purse per team"><Seg disabled={!isHost} value={settings.purse} onChange={(v) => set('purse', v)} options={[[10000, '₹100 Cr'], [12000, '₹120 Cr'], [15000, '₹150 Cr']]} /></SettingRow>
              <SettingRow label="Bid timer"><Seg disabled={!isHost} value={settings.timer} onChange={(v) => set('timer', v)} options={[[10, '10s'], [15, '15s'], [20, '20s']]} /></SettingRow>
              <SettingRow label="Max squad size"><Seg disabled={!isHost} value={settings.maxSquad} onChange={(v) => set('maxSquad', v)} options={[[20, '20'], [22, '22'], [25, '25']]} /></SettingRow>
              <SettingRow label="AI bot teams" hint="Fill empty franchises with bidders that respect purse and balance">
                <Toggle disabled={!isHost} checked={settings.bots} onChange={(v) => set('bots', v)} label="AI bot teams" />
              </SettingRow>
              {settings.bots && (
                <SettingRow label="Total teams" hint="Humans plus bots">
                  <select disabled={!isHost} className="field h-9 w-24" value={settings.teamCount} onChange={(e) => set('teamCount', +e.target.value)}>
                    {[2, 3, 4, 5, 6, 7, 8, 9, 10].map((n) => <option key={n} value={n}>{n}</option>)}
                  </select>
                </SettingRow>
              )}
              <SettingRow label="Retention phase" hint="Keep up to 6 players from last season before bidding"><Toggle disabled={!isHost} checked={settings.retention} onChange={(v) => set('retention', v)} label="Retention phase" /></SettingRow>
              <SettingRow label="RTM cards" hint="6 minus retentions per team"><Toggle disabled={!isHost} checked={settings.rtm} onChange={(v) => set('rtm', v)} label="RTM cards" /></SettingRow>
              <SettingRow label="Unsold re-entry round" hint="Unsold players come back at half base price"><Toggle disabled={!isHost} checked={settings.reentry} onChange={(v) => set('reentry', v)} label="Unsold re-entry" /></SettingRow>
              <SettingRow label="Shuffle players within each set"><Toggle disabled={!isHost} checked={settings.randomize} onChange={(v) => set('randomize', v)} label="Shuffle" /></SettingRow>
            </div>
          </section>
        </div>

        <aside className="space-y-5">
          <section className="panel p-5">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-[15px] font-medium">Managers</h2>
              <span className="num font-mono text-[12px] text-fg-3">{members.length}</span>
            </div>
            <ul className="space-y-1">
              {members.map(([u, m]) => (
                <li key={u} className="flex h-11 items-center gap-3 rounded-lg px-2 hover:bg-ink-800">
                  <div className="relative"><Avatar name={m.name} color={m.color} size={28} /><span className="absolute -bottom-0.5 -right-0.5 rounded-full ring-2 ring-ink-850"><PresenceDot m={m} /></span></div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5 truncate text-[14px]">
                      {m.name}{u === uid && <span className="text-fg-3">(you)</span>}
                      {S.meta.hostId === u && <LuCrown size={14} className="text-brass" aria-label="Host" />}
                    </div>
                    <div className="text-[12px] text-fg-3">{m.team ? TEAMS[m.team].short : m.spectator ? 'Watching' : 'No team yet'}</div>
                  </div>
                  {m.team && <Paddle team={m.team} size={22} />}
                  {m.ready ? <LuCheck size={16} className="text-good" aria-label="Ready" /> : <span className="w-4" />}
                  {isHost && u !== uid && (
                    <div className="flex">
                      <button className="btn btn-ghost btn-sm px-1.5" title="Make host" onClick={() => transferHost(code, u)}><LuCrown size={16} /></button>
                      <button className="btn btn-ghost btn-sm px-1.5" title="Remove" onClick={() => confirm(`Remove ${m.name}?`) && kick(code, S, u)}><LuUserX size={16} /></button>
                    </div>
                  )}
                </li>
              ))}
              {settings.bots && Array.from({ length: Math.max(0, totalTeams - humanTeams) }).map((_, i) => (
                <li key={'b' + i} className="flex h-11 items-center gap-3 px-2 text-fg-3">
                  <span className="flex size-7 items-center justify-center rounded-full bg-ink-800"><LuBot size={16} /></span>
                  <span className="text-[14px]">AI bot</span>
                </li>
              ))}
            </ul>
            <div className="mt-4 grid gap-2">
              <button className={`btn ${me?.ready ? 'border-good/50 text-good' : ''}`} onClick={() => setReady(code, !me?.ready)}>
                <LuCheck size={16} /> {me?.ready ? 'Ready' : "I'm ready"}
              </button>
              {isHost ? (
                <button className="btn btn-primary h-12 text-[15px]" disabled={starting || totalTeams < 2} onClick={start}>
                  {settings.retention ? 'Start retentions' : 'Start the auction'}
                </button>
              ) : (
                <p className="text-center text-[13px] text-fg-3">Waiting for {S.members?.[S.meta.hostId]?.name || 'the host'} to start</p>
              )}
              {!isHost && hostAway && <button className="btn btn-sm" onClick={() => takeHost(code)}>Host is away. Take over as host</button>}
            </div>
          </section>
          <section className="panel h-[420px] overflow-hidden">
            <div className="flex h-12 items-center border-b border-line px-4 text-[14px] font-medium">Lobby chat</div>
            <Chat className="h-[calc(100%-48px)]" taunts={false} />
          </section>
        </aside>
      </main>
      <RulesModal open={rules} onClose={() => setRules(false)} />
    </div>
  );
}

function SettingRow({ label, hint, children }) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-3 py-3">
      <div className="min-w-0">
        <div className="text-[14px]">{label}</div>
        {hint && <div className="text-[12px] text-fg-3">{hint}</div>}
      </div>
      {children}
    </div>
  );
}

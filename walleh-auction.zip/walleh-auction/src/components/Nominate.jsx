import { useState } from 'react';
import { LuCheck, LuSearch } from 'react-icons/lu';
import { useRoom } from './Room';
import { availableForNomination, setNominations, startAccelerated } from '../lib/engine';
import { fmt, arr } from '../lib/rules';
import { Modal, Paddle, RoleTag, CountryTag } from './ui';

export default function Nominate() {
  const { code, S, myTeam, isHost } = useRoom();
  const [q, setQ] = useState('');
  const mine = arr(S.nominations?.[myTeam]);
  const avail = availableForNomination(S).filter((p) => !q || p.name.toLowerCase().includes(q.toLowerCase())).sort((a, b) => b.rating - a.rating);
  const toggle = (id) => setNominations(code, myTeam, mine.includes(id) ? mine.filter((x) => x !== id) : mine.length < 5 ? [...mine, id] : mine);
  const total = new Set(Object.values(S.nominations || {}).flatMap(arr)).size;
  return (
    <Modal open title="Accelerated round: nominate up to 5" footer={
      <div className="flex items-center justify-between gap-3">
        <div className="flex -space-x-1">{Object.keys(S.teams || {}).map((t) => <Paddle key={t} team={t} size={22} dim={!arr(S.nominations?.[t]).length} />)}</div>
        {isHost ? <button className="btn btn-primary" onClick={() => startAccelerated(code, S)}>Start with {total} players</button> : <span className="text-[13px] text-fg-3">{total} nominated so far</span>}
      </div>}>
      {myTeam ? (
        <>
          <p className="mb-3 text-[13px] text-fg-2">Pick players you want brought back. Each lot gets a shorter timer. {mine.length}/5 picked.</p>
          <div className="relative mb-2">
            <LuSearch size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-fg-3" />
            <input className="field h-10 pl-9" placeholder="Search remaining players" value={q} onChange={(e) => setQ(e.target.value)} />
          </div>
          <ul className="divide-y divide-line">
            {avail.slice(0, 120).map((p) => {
              const on = mine.includes(p.id);
              return (
                <li key={p.id}>
                  <button className="flex w-full items-center gap-3 py-2 text-left" onClick={() => toggle(p.id)}>
                    <span className={`flex size-5 shrink-0 items-center justify-center rounded-md border ${on ? 'border-brass bg-brass text-ink-900' : 'border-line-2'}`}>{on && <LuCheck size={14} />}</span>
                    <span className="min-w-0 flex-1 truncate text-[13px]">{p.name}</span>
                    <RoleTag p={p} />{p.isOverseas && <CountryTag country={p.country} />}
                    <span className="num w-14 text-right font-mono text-[12px] text-fg-2">{fmt(p.basePrice)}</span>
                  </button>
                </li>
              );
            })}
          </ul>
        </>
      ) : <p className="text-fg-2">Teams are nominating players for the accelerated round.</p>}
    </Modal>
  );
}

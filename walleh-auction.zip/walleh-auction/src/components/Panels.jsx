import { useMemo, useState } from 'react';
import { LuStar, LuSearch, LuTriangleAlert, LuShuffle } from 'react-icons/lu';
import { useRoom } from './Room';
import { saveXI } from '../lib/engine';
import { PLAYERS, PLAYER_MAP } from '../data/playersData';
import {
  TEAMS, fmt, squadOf, overseasCount, composition, balanceWarnings, roleSpend, teamStrength, autoXI, MIN_SQUAD, MAX_OVERSEAS, arr,
} from '../lib/rules';
import { Paddle, PresenceDot, Bar, Modal, CountryTag, RoleTag, Empty, useToast } from './ui';

/* Private shortlist + notes (this browser only) */
export function useLocal(key, init) {
  const [v, setV] = useState(() => { try { return JSON.parse(localStorage.getItem(key)) ?? init; } catch { return init; } });
  const set = (nv) => { const val = typeof nv === 'function' ? nv(v) : nv; setV(val); localStorage.setItem(key, JSON.stringify(val)); };
  return [v, set];
}

export function TeamsPanel({ onRival }) {
  const { S, settings, myTeam } = useRoom();
  const [compare, setCompare] = useState(false);
  const ids = Object.keys(S.teams || {});
  const maxSpent = Math.max(1, ...ids.map((t) => settings.purse - S.teams[t].purse));
  return (
    <div>
      <div className="mb-2 flex items-center justify-between px-1">
        <h2 className="text-[14px] font-medium">All teams</h2>
        <div className="inline-flex rounded-lg border border-line bg-ink-900 p-0.5 text-[12px]">
          {[[false, 'Purses'], [true, 'Spend']].map(([v, l]) => (
            <button key={l} onClick={() => setCompare(v)} className={`h-6 rounded-md px-2 transition-colors ${compare === v ? 'bg-ink-700 text-fg' : 'text-fg-3 hover:text-fg'}`}>{l}</button>
          ))}
        </div>
      </div>
      <ul className="space-y-1">
        {ids.map((t) => {
          const tm = S.teams[t];
          const sq = squadOf(tm).length;
          const os = overseasCount(tm);
          const spent = settings.purse - tm.purse;
          const owner = S.members?.[tm.owner];
          return (
            <li key={t}>
              <button onClick={() => onRival?.(t)} className={`w-full rounded-xl px-2.5 py-2.5 text-left transition-colors hover:bg-ink-800 ${t === myTeam ? 'bg-ink-800/70' : ''}`}>
                <div className="flex items-center gap-2.5">
                  <Paddle team={t} size={28} />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5 truncate text-[13px] font-medium">
                      {tm.owner === 'BOT' ? 'AI bot' : owner?.name || 'Manager'}{t === myTeam && <span className="font-normal text-fg-3">(you)</span>}
                      {tm.owner !== 'BOT' && <PresenceDot m={owner} />}
                    </div>
                    <div className="num truncate font-mono text-[12px] text-fg-3">{sq}/{settings.maxSquad} · {os}/{MAX_OVERSEAS} OS{settings.rtm ? ` · RTM ${tm.rtm || 0}` : ''}</div>
                  </div>
                  <div className="num text-right font-mono text-[13px] text-fg">{fmt(compare ? spent : tm.purse)}</div>
                </div>
                <div className="mt-2 pl-[38px]">
                  {compare
                    ? <Bar value={spent} max={maxSpent} color={TEAMS[t].ink} h={6} />
                    : <Bar value={spent} max={settings.purse} color={spent / settings.purse > 0.85 ? 'var(--color-bad)' : 'var(--color-fg-3)'} />}
                  {!compare && <div className="num mt-1 text-[11px] text-fg-3">{Math.round((spent / settings.purse) * 100)}% spent</div>}
                </div>
              </button>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

export function soldList(S) {
  return Object.entries(S.players || {}).filter(([, v]) => v.status === 'sold' && v.price).map(([pid, v]) => ({ p: PLAYER_MAP[pid], ...v })).filter((x) => x.p);
}
export function stealOf(sold) {
  return sold.filter((x) => x.p.rating >= 72).map((x) => ({ ...x, score: x.p.rating / (x.price / x.p.basePrice) })).sort((a, b) => b.score - a.score)[0];
}

export function FeedPanel({ limit }) {
  const { S, feed } = useRoom();
  const sold = soldList(S);
  const top = [...sold].sort((a, b) => b.price - a.price)[0];
  const steal = stealOf(sold);
  const items = Object.entries(feed || {}).sort(([a], [b]) => (a > b ? -1 : 1)).map(([k, v]) => ({ k, ...v })).slice(0, limit || 200);
  return (
    <div>
      {!limit && (
        <div className="mb-4 grid grid-cols-2 gap-2">
          <Tracker label="Most expensive" x={top} />
          <Tracker label="Steal of the auction" x={steal} />
        </div>
      )}
      {!items.length && <Empty>Sold and unsold calls show up here</Empty>}
      <ul className="space-y-0.5">
        {items.map((e) => (
          <li key={e.k} className="flex items-center gap-2.5 rounded-lg px-1.5 py-1.5">
            <span className="num w-10 shrink-0 font-mono text-[11px] text-fg-3">{e.ts ? new Date(e.ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }) : ''}</span>
            {e.team ? <Paddle team={e.team} size={18} /> : <span className={`ml-[5px] mr-[5px] size-2 shrink-0 rounded-full ${e.type === 'unsold' ? 'bg-bad/70' : 'bg-fg-3'}`} />}
            <span className={`min-w-0 flex-1 text-[13px] ${e.type === 'unsold' ? 'text-fg-3' : 'text-fg-2'}`}>{e.text}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
function Tracker({ label, x }) {
  return (
    <div className="raised rounded-xl p-3">
      <div className="label">{label}</div>
      {x ? (
        <>
          <div className="mt-1 truncate text-[13px] font-medium">{x.p.name}</div>
          <div className="mt-1 flex items-center gap-1.5"><Paddle team={x.team} size={16} /><span className="num font-mono text-[13px] text-brass">{fmt(x.price)}</span></div>
        </>
      ) : <div className="mt-1 text-[13px] text-fg-3">None yet</div>}
    </div>
  );
}

export function PoolPanel({ onPlayerInfo }) {
  const { code, S } = useRoom();
  const [q, setQ] = useState('');
  const [role, setRole] = useState('');
  const [origin, setOrigin] = useState('');
  const [status, setStatus] = useState('');
  const [base, setBase] = useState('');
  const [stars, setStars] = useLocal(`walleh-stars-${code}`, []);
  const L = S.live;
  const statusOf = (p) => (L?.pid === p.id && L.stage !== 'result' ? 'live' : S.players?.[p.id]?.status || 'upcoming');
  const rows = useMemo(() => PLAYERS.filter((p) => {
    if (q && !p.name.toLowerCase().includes(q.toLowerCase())) return false;
    if (role && p.role !== role) return false;
    if (origin === 'IND' && p.isOverseas) return false;
    if (origin === 'OS' && !p.isOverseas) return false;
    if (base && p.basePrice !== +base) return false;
    const st = statusOf(p);
    if (status === 'star') return stars.includes(p.id);
    if (status && st !== status && !(status === 'sold' && st === 'retained')) return false;
    return true;
  }), [q, role, origin, status, base, S.players, L?.pid, stars]);
  const sel = 'field h-9 px-2 text-[13px]';
  return (
    <div>
      <div className="relative mb-2">
        <LuSearch size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-fg-3" />
        <input className="field h-10 pl-9" placeholder="Search players" value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      <div className="mb-3 grid grid-cols-2 gap-2">
        <select className={sel} value={role} onChange={(e) => setRole(e.target.value)} aria-label="Role"><option value="">All roles</option>{['Batter', 'Wicketkeeper', 'All-Rounder', 'Bowler'].map((r) => <option key={r}>{r}</option>)}</select>
        <select className={sel} value={origin} onChange={(e) => setOrigin(e.target.value)} aria-label="Origin"><option value="">India and overseas</option><option value="IND">India</option><option value="OS">Overseas</option></select>
        <select className={sel} value={base} onChange={(e) => setBase(e.target.value)} aria-label="Base price"><option value="">Any base price</option>{[200, 150, 100, 75, 50, 40, 30].map((b) => <option key={b} value={b}>{fmt(b)}</option>)}</select>
        <select className={sel} value={status} onChange={(e) => setStatus(e.target.value)} aria-label="Status"><option value="">Any status</option><option value="upcoming">Upcoming</option><option value="sold">Sold</option><option value="unsold">Unsold</option><option value="star">My shortlist</option></select>
      </div>
      <div className="mb-1 px-1 text-[12px] text-fg-3">{rows.length} players</div>
      <ul className="divide-y divide-line">
        {rows.map((p) => {
          const st = statusOf(p);
          const info = S.players?.[p.id];
          const on = stars.includes(p.id);
          return (
            <li key={p.id} className="flex items-center gap-2 py-2">
              <button className={`btn btn-ghost size-8 shrink-0 p-0 ${on ? 'text-brass' : 'text-fg-3'}`} onClick={() => setStars(on ? stars.filter((x) => x !== p.id) : [...stars, p.id])} aria-label={on ? 'Remove from shortlist' : 'Add to shortlist'}>
                <LuStar size={16} fill={on ? 'currentColor' : 'none'} />
              </button>
              <button className="min-w-0 flex-1 text-left" onClick={() => onPlayerInfo?.(p)}>
                <div className="truncate text-[13px] font-medium">{p.name}</div>
                <div className="mt-0.5 flex items-center gap-1"><RoleTag p={p} />{p.isOverseas && <CountryTag country={p.country} />}<span className="text-[11px] text-fg-3">{fmt(p.basePrice)}</span></div>
              </button>
              <div className="shrink-0 text-right text-[12px]">
                {st === 'live' && <span className="text-brass">On the block</span>}
                {(st === 'sold' || st === 'retained') && <span className="flex items-center gap-1.5"><Paddle team={info.team} size={16} /><span className="num font-mono text-fg-2">{fmt(info.price)}</span></span>}
                {st === 'unsold' && <span className="text-fg-3">Unsold</span>}
                {st === 'upcoming' && <span className="text-fg-3">{p.set.replace('Capped ', '').replace('Uncapped ', 'Unc. ')}</span>}
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

export function PlayerInfoModal({ p, onClose }) {
  const { code, S } = useRoom();
  const [notes, setNotes] = useLocal(`walleh-notes-${code}`, {});
  const [stars, setStars] = useLocal(`walleh-stars-${code}`, []);
  if (!p) return null;
  const info = S.players?.[p.id];
  const on = stars.includes(p.id);
  const s = p.stats;
  return (
    <Modal open onClose={onClose} title={p.name}>
      <div className="flex flex-wrap gap-1.5"><CountryTag country={p.country} /><RoleTag p={p} /><span className="chip">{p.status}</span><span className="chip">{p.set}</span></div>
      <div className="mt-4 grid grid-cols-3 gap-2">
        {[['Rating', p.rating], ['Base', fmt(p.basePrice)], ['Last team', p.previousTeam || '—'], ['Matches', s.matches], ['Runs', s.runs], ['Strike rate', s.sr || '—'], ['Wickets', s.wickets], ['Economy', s.econ || '—'], ['Status', info ? (info.status === 'sold' || info.status === 'retained' ? `${info.team} ${fmt(info.price)}` : 'Unsold') : 'Upcoming']].map(([k, v]) => (
          <div key={k} className="raised rounded-lg p-2.5"><div className="label">{k}</div><div className="num mt-0.5 font-mono text-[14px]">{v}</div></div>
        ))}
      </div>
      <p className="mt-2 text-[11px] text-fg-3">Stats are approximate career T20 figures</p>
      <div className="mt-5 flex items-center justify-between">
        <span className="label">Private note (only on this device)</span>
        <button className={`btn btn-sm ${on ? 'text-brass' : ''}`} onClick={() => setStars(on ? stars.filter((x) => x !== p.id) : [...stars, p.id])}><LuStar size={14} fill={on ? 'currentColor' : 'none'} /> {on ? 'Shortlisted' : 'Shortlist'}</button>
      </div>
      <textarea className="field mt-2 h-24 py-2" placeholder="Max ₹6 Cr. Need him if we lose the WK battle" value={notes[p.id] || ''} onChange={(e) => setNotes({ ...notes, [p.id]: e.target.value })} />
    </Modal>
  );
}

export function SquadPanel({ team, onXI }) {
  const { S, settings, myTeam } = useRoom();
  const tm = S.teams?.[team];
  if (!tm) return <Empty>You're spectating. Tap a team to inspect its squad.</Empty>;
  const sq = squadOf(tm).sort((a, b) => b.price - a.price);
  const c = composition(tm);
  const warns = balanceWarnings(tm);
  const spend = roleSpend(tm);
  const slots = Math.max(0, MIN_SQUAD - sq.length);
  const open = Math.max(1, settings.maxSquad - sq.length);
  const os = overseasCount(tm);
  const xi = arr(tm.xi);
  return (
    <div>
      <div className="grid grid-cols-3 gap-2">
        <Stat label="Strength" v={teamStrength(tm)} />
        <Stat label="Avg per open slot" v={fmt(Math.floor(tm.purse / open))} />
        <Stat label="Must still buy" v={slots} />
      </div>
      {os >= MAX_OVERSEAS - 1 && <div className="mt-3 flex items-center gap-2 rounded-lg border border-warn/30 bg-warn/10 px-3 py-2 text-[13px] text-warn"><LuTriangleAlert size={16} /> {os}/{MAX_OVERSEAS} overseas slots used</div>}
      {warns.length > 0 && <div className="mt-3 flex flex-wrap gap-1.5">{warns.map((w) => <span key={w} className="chip h-6 border-warn/30 text-warn">{w}</span>)}</div>}

      <div className="mt-5">
        <div className="label mb-2">Squad mix and spend</div>
        <div className="space-y-2">
          {['Batters', 'Wicketkeepers', 'All-Rounders', 'Bowlers'].map((r) => (
            <div key={r} className="grid grid-cols-[92px_1fr_auto] items-center gap-3 text-[13px]">
              <span className="text-fg-2">{r}</span>
              <Bar value={c[r]} max={Math.max(8, ...Object.values(c))} color={TEAMS[team].ink} h={6} />
              <span className="num whitespace-nowrap text-right font-mono text-[12px] text-fg-2">{c[r]} · {fmt(spend[r])}</span>
            </div>
          ))}
        </div>
        <div className="mt-2 text-[12px] text-fg-3">{c.Spinners} spin and {c.Pacers} pace options</div>
      </div>

      <div className="mt-5 flex items-center justify-between">
        <div className="label">Players ({sq.length}/{settings.maxSquad})</div>
        {team === myTeam && <button className="btn btn-sm" onClick={onXI}>Playing XI{xi.length ? ` (${xi.length})` : ''}</button>}
      </div>
      {!sq.length && <Empty>No players yet</Empty>}
      <ul className="mt-1 divide-y divide-line">
        {sq.map((s) => (
          <li key={s.pid} className="flex items-center gap-2 py-2">
            <div className="min-w-0 flex-1">
              <div className="truncate text-[13px] font-medium">{s.p.name}{xi.includes(s.pid) && <span className="ml-1.5 text-[11px] text-brass">XI</span>}{tm.impact === s.pid && <span className="ml-1.5 text-[11px] text-brass">Impact</span>}</div>
              <div className="mt-0.5 flex items-center gap-1"><RoleTag p={s.p} />{s.p.isOverseas && <CountryTag country={s.p.country} />}{s.how !== 'auction' && <span className="text-[11px] text-fg-3">{s.how === 'rtm' ? 'RTM' : s.how}</span>}</div>
            </div>
            <span className="num font-mono text-[13px]">{fmt(s.price)}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
const Stat = ({ label, v }) => <div className="raised rounded-xl p-3"><div className="label">{label}</div><div className="num mt-1 font-display text-[22px] font-semibold leading-none">{v}</div></div>;

export function RivalModal({ team, onClose }) {
  const { S } = useRoom();
  if (!team) return null;
  const tm = S.teams?.[team];
  return (
    <Modal open onClose={onClose} title={<span className="flex items-center gap-2"><Paddle team={team} size={22} /> {TEAMS[team].name} <span className="num font-mono text-[13px] text-fg-2">{fmt(tm?.purse)} left</span></span>}>
      <SquadPanel team={team} />
    </Modal>
  );
}

export function XIBuilder({ open, onClose }) {
  const { code, S, myTeam } = useRoom();
  const toast = useToast();
  const tm = S.teams?.[myTeam];
  const [xi, setXi] = useState(() => arr(tm?.xi));
  const [impact, setImpact] = useState(tm?.impact ?? null);
  if (!open || !tm) return null;
  const sq = squadOf(tm).sort((a, b) => b.p.rating - a.p.rating);
  const os = xi.filter((pid) => PLAYER_MAP[pid].isOverseas).length;
  const toggle = (pid) => {
    if (xi.includes(pid)) return setXi(xi.filter((x) => x !== pid));
    if (xi.length >= 11) return toast('XI is full. Tap a player to drop him');
    if (PLAYER_MAP[pid].isOverseas && os >= 4) return toast('Only 4 overseas players in the XI');
    if (impact === pid) setImpact(null);
    setXi([...xi, pid]);
  };
  const auto = () => { const a = autoXI(sq.map((s) => s.p)).map((p) => p.id); setXi(a); setImpact(sq.find((s) => !a.includes(s.pid))?.pid ?? null); };
  return (
    <Modal open onClose={onClose} title="Playing XI" footer={
      <div className="flex gap-2">
        <button className="btn" onClick={auto}><LuShuffle size={16} /> Auto pick</button>
        <button className="btn btn-primary flex-1" onClick={() => { saveXI(code, myTeam, xi, impact); toast('Playing XI saved'); onClose(); }}>Save XI</button>
      </div>}>
      <div className="mb-3 flex justify-between text-[13px] text-fg-2"><span>{xi.length}/11 picked · {os}/4 overseas</span><span>Tap to add or drop</span></div>
      <ul className="space-y-1">
        {sq.map((s) => {
          const inXI = xi.includes(s.pid);
          return (
            <li key={s.pid} className={`flex items-center gap-2 rounded-lg border px-2.5 py-2 ${inXI ? 'border-brass/50 bg-ink-800' : 'border-line'}`}>
              <button className="flex min-w-0 flex-1 items-center gap-2 text-left" onClick={() => toggle(s.pid)}>
                <span className="num w-5 font-mono text-[12px] text-fg-3">{inXI ? xi.indexOf(s.pid) + 1 : ''}</span>
                <span className="min-w-0 flex-1 truncate text-[13px]">{s.p.name}</span>
                <RoleTag p={s.p} />
              </button>
              {!inXI && <button className={`btn btn-sm h-7 ${impact === s.pid ? 'border-brass text-brass' : ''}`} onClick={() => setImpact(impact === s.pid ? null : s.pid)}>Impact</button>}
            </li>
          );
        })}
      </ul>
      {!sq.length && <Empty>Buy some players first</Empty>}
    </Modal>
  );
}

import { LuCheck } from 'react-icons/lu';
import { useRoom } from './Room';
import { setRetained, retentionCost, finishRetention } from '../lib/engine';
import { PLAYERS, PLAYER_MAP } from '../data/playersData';
import { TEAMS, fmt, arr, MAX_RETAIN, MAX_RETAIN_CAPPED, MAX_RETAIN_UNCAPPED } from '../lib/rules';
import { Paddle, CountryTag, RoleTag, Logo, Empty } from './ui';

export default function Retention() {
  const { code, S, settings, myTeam, isHost } = useRoom();
  const teams = Object.keys(S.teams || {});
  const mine = arr(S.retained?.[myTeam]);
  const eligible = myTeam ? PLAYERS.filter((p) => p.previousTeam === myTeam).sort((a, b) => b.rating - a.rating) : [];
  const capped = mine.filter((pid) => PLAYER_MAP[pid].status === 'Capped').length;
  const unc = mine.length - capped;
  const costs = retentionCost(mine);
  const spent = costs.reduce((a, b) => a + b, 0);

  const toggle = (p) => {
    if (mine.includes(p.id)) return setRetained(code, myTeam, mine.filter((x) => x !== p.id));
    if (mine.length >= MAX_RETAIN) return;
    if (p.status === 'Capped' && capped >= MAX_RETAIN_CAPPED) return;
    if (p.status === 'Uncapped' && unc >= MAX_RETAIN_UNCAPPED) return;
    setRetained(code, myTeam, [...mine, p.id]);
  };

  return (
    <div className="min-h-dvh">
      <header className="sticky top-0 z-30 border-b border-line bg-ink-900/90 backdrop-blur">
        <div className="mx-auto flex h-14 max-w-6xl items-center justify-between px-4 sm:px-6">
          <Logo small />
          <span className="text-[13px] text-fg-2">Retention phase</span>
        </div>
      </header>
      <main className="mx-auto grid max-w-6xl gap-5 px-4 py-5 sm:px-6 lg:grid-cols-[1fr_340px] lg:py-8">
        <section className="panel p-5">
          {myTeam ? (
            <>
              <div className="mb-4 flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <Paddle team={myTeam} size={40} />
                  <div>
                    <h1 className="text-[17px] font-medium">Retain from last season</h1>
                    <p className="text-[13px] text-fg-2">Up to 6 players: 5 capped, 2 uncapped. Unused slots become RTM cards.</p>
                  </div>
                </div>
                <div className="flex gap-6 text-right">
                  <div><div className="label">Spent</div><div className="num font-display text-[24px] font-semibold">{fmt(spent)}</div></div>
                  <div><div className="label">Purse left</div><div className="num font-display text-[24px] font-semibold text-brass">{fmt(settings.purse - spent)}</div></div>
                  <div><div className="label">RTMs</div><div className="num font-display text-[24px] font-semibold">{settings.rtm ? MAX_RETAIN - mine.length : 0}</div></div>
                </div>
              </div>
              {!eligible.length && <Empty>No players from {TEAMS[myTeam].short} last season in the pool</Empty>}
              <ul className="divide-y divide-line">
                {eligible.map((p) => {
                  const i = mine.indexOf(p.id);
                  const on = i >= 0;
                  return (
                    <li key={p.id}>
                      <button onClick={() => toggle(p)} className={`flex w-full items-center gap-3 rounded-lg px-2 py-2.5 text-left transition-colors ${on ? 'bg-ink-800' : 'hover:bg-ink-800/60'}`}>
                        <span className={`flex size-5 shrink-0 items-center justify-center rounded-md border ${on ? 'border-brass bg-brass text-ink-900' : 'border-line-2'}`}>{on && <LuCheck size={14} />}</span>
                        <div className="min-w-0 flex-1">
                          <div className="truncate text-[14px] font-medium">{p.name}</div>
                          <div className="mt-1 flex gap-1.5"><CountryTag country={p.country} /><RoleTag p={p} /><span className="chip">{p.status}</span></div>
                        </div>
                        <span className="num w-10 text-right font-mono text-[13px] text-fg-2">{p.rating}</span>
                        <span className="num w-20 text-right font-mono text-[13px]">{on ? fmt(costs[i]) : <span className="text-fg-3">—</span>}</span>
                      </button>
                    </li>
                  );
                })}
              </ul>
            </>
          ) : <Empty>You're watching. Teams are choosing their retentions.</Empty>}
        </section>
        <aside className="panel h-fit p-5">
          <h2 className="mb-3 text-[15px] font-medium">All franchises</h2>
          <ul className="space-y-3">
            {teams.map((t) => {
              const r = arr(S.retained?.[t]);
              const c = retentionCost(r).reduce((a, b) => a + b, 0);
              return (
                <li key={t} className="flex items-start gap-3">
                  <Paddle team={t} size={28} />
                  <div className="min-w-0 flex-1">
                    <div className="flex justify-between text-[13px]"><span>{S.members?.[S.teams[t].owner]?.name || 'AI bot'}</span><span className="num font-mono text-fg-2">{fmt(c)}</span></div>
                    <div className="mt-0.5 truncate text-[12px] text-fg-3">{r.length ? r.map((pid) => PLAYER_MAP[pid].name).join(', ') : 'No retentions yet'}</div>
                  </div>
                </li>
              );
            })}
          </ul>
          {isHost ? (
            <button className="btn btn-primary mt-5 h-11 w-full" onClick={() => finishRetention(code, S)}>Lock retentions and start bidding</button>
          ) : <p className="mt-5 text-center text-[13px] text-fg-3">The host locks retentions when everyone is done</p>}
        </aside>
      </main>
    </div>
  );
}

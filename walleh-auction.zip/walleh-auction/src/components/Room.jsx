import { createContext, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { db, now } from '../lib/db';
import { hostTick, botTick } from '../lib/engine';
import { DEFAULT_SETTINGS } from '../lib/rules';
import Lobby from './Lobby';
import Retention from './Retention';
import Auction from './Auction';
import Summary from './Summary';

const RoomCtx = createContext(null);
export const useRoom = () => useContext(RoomCtx);

const NODES = ['meta', 'members', 'teams', 'players', 'queue', 'live', 'claims', 'retained', 'nominations', 'trades'];

// Firebase turns objects with numeric keys (player ids) into sparse arrays. Turn them back.
const obj = (x) => (Array.isArray(x) ? Object.fromEntries(x.map((v, i) => [i, v]).filter(([, v]) => v != null)) : x);
function normalize(n, v) {
  if (!v) return v;
  if (n === 'players') return obj(v);
  if (n === 'teams') return Object.fromEntries(Object.entries(v).map(([t, tm]) => [t, { ...tm, squad: obj(tm.squad) || {} }]));
  if (n === 'queue') return { ...v, reduced: obj(v.reduced) };
  return v;
}

export default function Room({ code, onExit }) {
  const [S, setS] = useState({});
  const [chat, setChat] = useState({});
  const [feed, setFeed] = useState({});
  const [reactions, setReactions] = useState({});
  const [kicked, setKicked] = useState(false);
  const [connected, setConnected] = useState(true);
  const [latency, setLatency] = useState(null);
  const [loaded, setLoaded] = useState(false);
  const ref = useRef(S);
  ref.current = S;
  const base = `rooms/${code}`;

  useEffect(() => {
    const offs = NODES.map((n) => db.listen(`${base}/${n}`, (v) => { setS((s) => ({ ...s, [n]: normalize(n, v) })); if (n === 'meta') setLoaded(true); }));
    offs.push(db.listen(`${base}/chat`, (v) => setChat(v || {}), { last: 60 }));
    offs.push(db.listen(`${base}/feed`, (v) => setFeed(v || {}), { last: 120 }));
    offs.push(db.listen(`${base}/reactions`, (v) => setReactions(v || {}), { last: 12 }));
    offs.push(db.listen(`${base}/kicked/${db.uid}`, (v) => setKicked(!!v)));
    return () => offs.forEach((o) => o && o());
  }, [code]);

  // Presence + latency.
  useEffect(() => {
    const me = `${base}/members/${db.uid}`;
    const off = db.watchConnection((c) => {
      setConnected(c);
      if (c) {
        db.onDisconnectUpdate(me, { online: false, lastSeen: db.serverTs() });
        db.update(me, { online: true, lastSeen: db.serverTs() });
      }
    });
    const ping = async () => {
      const t = performance.now();
      try { await db.set(`${me}/ping`, Date.now()); setLatency(Math.round(performance.now() - t)); } catch { setLatency(null); }
    };
    ping();
    const i = setInterval(ping, 15000);
    return () => { off && off(); clearInterval(i); };
  }, [code]);

  const isHost = S.meta?.hostId === db.uid;

  // The host's browser runs the clock and the bots.
  useEffect(() => {
    if (!isHost) return;
    const i = setInterval(() => {
      const cur = ref.current;
      hostTick(code, cur).catch((e) => console.warn(e));
      botTick(code, cur).catch((e) => console.warn(e));
    }, 300);
    return () => clearInterval(i);
  }, [isHost, code]);

  const value = useMemo(() => {
    const settings = { ...DEFAULT_SETTINGS, ...(S.meta?.settings || {}) };
    const me = S.members?.[db.uid] || null;
    const myTeam = S.teams ? Object.keys(S.teams).find((t) => S.teams[t].owner === db.uid) || null : me?.team || null;
    return { code, S, settings, me, myTeam, isHost, uid: db.uid, chat, feed, reactions, connected, latency, onExit };
  }, [S, chat, feed, reactions, connected, latency, isHost, code]);

  if (kicked) {
    return (
      <div className="flex min-h-dvh items-center justify-center p-6">
        <div className="panel max-w-sm p-6 text-center">
          <h1 className="text-[17px] font-medium">You were removed from this room</h1>
          <p className="mt-2 text-fg-2">The host took you out of room {code}.</p>
          <button className="btn mt-5" onClick={onExit}>Back to start</button>
        </div>
      </div>
    );
  }
  if (!loaded) return <div className="flex min-h-dvh items-center justify-center text-fg-3">Opening room {code}</div>;
  if (!S.meta) {
    return (
      <div className="flex min-h-dvh items-center justify-center p-6">
        <div className="panel max-w-sm p-6 text-center">
          <h1 className="text-[17px] font-medium">Room {code} doesn't exist</h1>
          <button className="btn mt-5" onClick={onExit}>Back to start</button>
        </div>
      </div>
    );
  }
  const phase = S.meta.phase;
  return (
    <RoomCtx.Provider value={value}>
      {phase === 'lobby' && <Lobby />}
      {phase === 'retention' && <Retention />}
      {(phase === 'auction' || phase === 'nominate') && <Auction />}
      {(phase === 'done' || phase === 'trade') && <Summary />}
    </RoomCtx.Provider>
  );
}

export function useHostAway() {
  const { S } = useRoom();
  const host = S.members?.[S.meta?.hostId];
  const [, t] = useState(0);
  useEffect(() => { const i = setInterval(() => t((x) => x + 1), 4000); return () => clearInterval(i); }, []);
  if (!host) return true;
  return !host.online && (!host.lastSeen || now() - host.lastSeen > 20000);
}

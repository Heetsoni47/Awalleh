import { Modal } from './ui';

const Row = ({ k, v }) => (
  <div className="flex items-center justify-between border-b border-line py-2 last:border-0">
    <span className="text-fg-2">{k}</span>
    <span className="num font-mono text-[13px]">{v}</span>
  </div>
);

export default function RulesModal({ open, onClose }) {
  return (
    <Modal open={open} onClose={onClose} title="Rules and bid slabs">
      <h3 className="label mb-1">Bid increments</h3>
      <div className="mb-5">
        <Row k="₹30 L to ₹1 Cr" v="+₹5 L" />
        <Row k="₹1 Cr to ₹2 Cr" v="+₹10 L" />
        <Row k="₹2 Cr to ₹5 Cr" v="+₹20 L" />
        <Row k="Above ₹5 Cr" v="+₹25 L" />
      </div>
      <h3 className="label mb-1">Squad</h3>
      <div className="mb-5">
        <Row k="Squad size" v="18 to 25" />
        <Row k="Overseas players" v="max 8" />
        <Row k="Purse" v="₹100 / 120 / 150 Cr" />
      </div>
      <h3 className="label mb-1">Retentions (if the host turns them on)</h3>
      <div className="mb-5">
        <Row k="Total retentions + RTMs" v="6" />
        <Row k="Capped slabs" v="18, 14, 11, 18, 14 Cr" />
        <Row k="Uncapped" v="₹4 Cr each, max 2" />
      </div>
      <h3 className="label mb-2">How the right to match works</h3>
      <ol className="mb-5 list-decimal space-y-1.5 pl-5 text-fg-2">
        <li>When bidding ends, the player's last-season team can use an RTM card.</li>
        <li>The highest bidder then gets one chance to raise their bid to any amount.</li>
        <li>The RTM team matches that final price and gets the player, or lets him go.</li>
      </ol>
      <h3 className="label mb-2">Good to know</h3>
      <ul className="list-disc space-y-1.5 pl-5 text-fg-2">
        <li>Each new bid resets the clock to 8 seconds, so last-second snipes get answered.</li>
        <li>The purse lock keeps enough money aside to fill 18 slots at ₹30 L each.</li>
        <li>Keyboard: <span className="kbd">Space</span> to bid, <span className="kbd">M</span> to mute.</li>
      </ul>
    </Modal>
  );
}

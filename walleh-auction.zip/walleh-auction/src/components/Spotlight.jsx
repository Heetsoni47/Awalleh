import { TEAMS, fmt } from '../lib/rules';
import { CountryTag, RoleTag, Paddle } from './ui';

/** The moment of the screen: a player card lit in the leading bidder's colours. */
export default function Spotlight({ p, lead, stamp, soldTo, soldPrice, compact = false, children, onInfo }) {
  const t = TEAMS[lead];
  const light = t ? t.color : '#3a4152';
  const s = p.stats;
  return (
    <div className="relative overflow-hidden rounded-[20px] border border-line bg-ink-850" style={{ isolation: 'isolate' }}>
      {/* Floodlight in the leading team's colour */}
      <div className="pointer-events-none absolute inset-0 -z-10 transition-[background] duration-500"
        style={{ background: `radial-gradient(120% 70% at 50% -10%, ${light}55 0%, ${light}18 40%, transparent 70%)` }} />
      <div className="pointer-events-none absolute inset-x-0 top-0 -z-10 h-px" style={{ background: `${light}aa` }} />

      <div className={compact ? 'p-4' : 'p-5 sm:p-6'}>
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-1.5">
              <CountryTag country={p.country} />
              <RoleTag p={p} />
              <span className="chip">{p.status}</span>
              {p.isOverseas && <span className="chip">Overseas</span>}
            </div>
            <button type="button" onClick={onInfo} className={`mt-3 block text-left font-display font-semibold leading-[0.95] tracking-[-0.01em] ${compact ? 'text-[32px]' : 'text-[40px] sm:text-[52px]'}`}>
              {p.name}
            </button>
            <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-[13px] text-fg-2">
              <span>Base {fmt(p.basePriceOverride ?? p.basePrice)}</span>
              {p.previousTeam && <span className="inline-flex items-center gap-1.5">Last season <Paddle team={p.previousTeam} size={16} /></span>}
            </div>
          </div>
          <div className="shrink-0 text-right">
            <div className="label">Rating</div>
            <div className="num font-display text-[40px] font-semibold leading-none text-fg">{p.rating}</div>
          </div>
        </div>

        <div className={`mt-5 grid grid-cols-5 gap-px overflow-hidden rounded-xl border border-line bg-line ${compact ? 'text-[12px]' : ''}`}>
          {[['Mat', s.matches], ['Runs', s.runs], ['SR', s.sr || '—'], ['Wkts', s.wickets], ['Econ', s.econ || '—']].map(([k, v]) => (
            <div key={k} className="bg-ink-850/90 px-2 py-2 text-center">
              <div className="label">{k}</div>
              <div className="num mt-0.5 font-mono text-[13px] text-fg">{v}</div>
            </div>
          ))}
        </div>
        {children}
      </div>

      {stamp && (
        <div className="pointer-events-none absolute inset-0 z-10 flex items-end justify-center bg-ink-950/30 pb-8 sm:pb-10">
          {stamp === 'sold' ? (
            <div className="animate-stamp rounded-2xl border-[3px] border-brass bg-ink-950/85 px-6 py-3 text-center shadow-[0_12px_40px_rgb(0_0_0/0.5)]">
              <div className="font-display text-[56px] font-semibold leading-none text-brass sm:text-[72px]">SOLD</div>
              <div className="mt-1 flex items-center justify-center gap-2 text-[15px]">
                <Paddle team={soldTo} size={22} />
                <span className="num font-medium">{fmt(soldPrice)}</span>
              </div>
            </div>
          ) : (
            <div className="animate-stamp rounded-2xl border-[3px] border-bad/80 bg-ink-950/85 px-6 py-3">
              <div className="font-display text-[48px] font-semibold leading-none text-bad sm:text-[60px]">UNSOLD</div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

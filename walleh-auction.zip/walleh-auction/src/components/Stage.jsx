import { useEffect, useMemo, useRef, useState } from 'react';
import { LuHand, LuChevronDown, LuPause } from 'react-icons/lu';
import { useRoom } from './Room';
import { placeBid, fold, rtmDecide, counterDecide, matchDecide, sendReaction, RTM_MS } from '../lib/engine';
import { PLAYER_MAP } from '../data/playersData';
import { TEAMS, fmt, increment, bidBlock, arr, maxAffordable } from '../lib/rules';
import { Paddle, Modal, useNow, useToast } from './ui';
import Spotlight from './Spotlight';
import { sfx } from '../lib/sound';
import { now } from '../lib/db';

const EMOJIS = ['🔥', '💸', '😱', '🏏', '😂'];

export function useAuctionSounds(L) {
  const prev = useRef({});
  useEffect(() => {
    if (!L) return;
    const p = prev.current;
    const hl = arr(L.history).length;
    if (p.seq === L.seq && hl > (p.hl || 0)) sfx.bid();
    if (p.stage !== L.stage || p.seq !== L.seq) {
      if (L.stage === 'result' && L.result?.type === 'sold') sfx.gavel();
      if (L.stage === 'result' && L.result?.type === 'unsold') sfx.unsold();
      if (L.stage === 'rtm') sfx.rtm();
    }
    prev.current = { seq: L.seq, stage: L.stage, hl };
  }, [L?.seq, L?.stage, arr(L?.history).length]);
}

function commentary(L, p) {
  if (!L || !p) return '';
  const h = arr(L.history);
  const n = p.name;
  if (L.stage === 'transition') return `Next up: ${L.set}`;
  if (L.stage === 'result') {
    const r = L.result;
    if (r?.type === 'unsold') return `No takers for ${n}. Back in the pool`;
    if (r?.how === 'rtm') return `${r.team} use the RTM. ${n} stays home for ${fmt(r.price)}`;
    if (r?.price >= L.base * 6) return `Big money. ${r.team} land ${n} for ${fmt(r.price)}`;
    if (r?.price === L.base) return `${n} snapped up at base price by ${r.team}`;
    return `${r?.team} land ${n} for ${fmt(r?.price)}`;
  }
  if (L.stage === 'rtm') return `${L.rtm.team} weighing up the RTM card for ${n}`;
  if (L.stage === 'counter') return `${L.rtm.team} raised the RTM. ${L.team} get one last chance to raise`;
  if (L.stage === 'match') return `${L.team} pushed it to ${fmt(L.amount)}. Will ${L.rtm.team} match?`;
  if (!h.length) return `${n} on the block at ${fmt(L.base)}. Who opens?`;
  const teams = [...new Set(h.slice(-4).map((x) => x.t))];
  if (L.amount >= 1500) return `${fmt(L.amount)} on the table for ${n}. This is getting serious`;
  if (teams.length >= 2 && h.length >= 3) return `${teams[teams.length - 1]} and ${teams[teams.length - 2]} locked in a fierce battle for ${n}`;
  if (h.length === 1) return `${L.team} open the bidding for ${n}`;
  return `${L.team} lead at ${fmt(L.amount)}`;
}

function TimerRing({ remain, total, size = 72 }) {
  const r = size / 2 - 5;
  const C = 2 * Math.PI * r;
  const frac = Math.max(0, Math.min(1, remain / total));
  const color = remain <= 3000 ? 'var(--color-bad)' : frac < 0.5 ? 'var(--color-warn)' : 'var(--color-good)';
  return (
    <div className="relative shrink-0" style={{ width: size, height: size }} role="timer" aria-label={`${Math.ceil(remain / 1000)} seconds left`}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} stroke="var(--color-ink-700)" strokeWidth="4" fill="none" />
        <circle cx={size / 2} cy={size / 2} r={r} stroke={color} strokeWidth="4" fill="none" strokeLinecap="round"
          strokeDasharray={C} strokeDashoffset={C * (1 - frac)} style={{ transition: 'stroke-dashoffset 200ms linear, stroke 300ms' }} />
      </svg>
      <div className="num absolute inset-0 flex items-center justify-center font-display text-[26px] font-semibold" style={{ color }}>{Math.ceil(remain / 1000)}</div>
    </div>
  );
}

function Reactions() {
  const { reactions } = useRoom();
  const t = useNow(400);
  const [mounted] = useState(Date.now());
  const live = Object.entries(reactions || {}).filter(([, r]) => r.ts > mounted - 500 && Date.now() - r.ts < 2600);
  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-0 z-20 h-0">
      {live.map(([k, r]) => {
        const x = 10 + ((parseInt(k.slice(-4), 36) || 0) % 80);
        return <span key={k} className="absolute bottom-0 text-[32px] animate-floatup" style={{ left: x + '%' }}>{r.e}</span>;
      })}
    </div>
  );
}

export default function Stage({ onPlayerInfo, compactFeed }) {
  const { code, S, settings, myTeam } = useRoom();
  const toast = useToast();
  const L = S.live;
  const t = useNow(150);
  const p = L?.pid ? PLAYER_MAP[L.pid] : null;
  const [jumpOpen, setJumpOpen] = useState(false);
  const [custom, setCustom] = useState('');
  const lastTick = useRef(0);
  useAuctionSounds(L);

  const list = arr(S.queue?.list);
  const team = myTeam ? S.teams?.[myTeam] : null;
  const isBidding = L?.stage === 'bidding' && !L.paused;
  const nb = L ? (L.team ? L.amount + increment(L.amount) : L.base) : 0;
  const remain = L?.stage === 'bidding' ? Math.max(0, L.endsAt - t) : ['rtm', 'counter', 'match'].includes(L?.stage) ? Math.max(0, L.rtm.endsAt - t) : 0;
  const total = L?.stage === 'bidding' ? (L.team ? settings.bidReset : S.queue?.round === 'accelerated' ? Math.min(10, settings.timer) : settings.timer) * 1000 : RTM_MS;

  useEffect(() => {
    if (L?.stage === 'bidding' && !L.paused && remain > 0 && remain <= 3000) {
      const s = Math.ceil(remain / 1000);
      if (s !== lastTick.current) { lastTick.current = s; sfx.tick(); }
    }
  }, [Math.ceil(remain / 1000)]);

  const block = useMemo(() => {
    if (!myTeam) return 'Spectating';
    if (!isBidding) return 'Bidding closed';
    if (L.team === myTeam) return "You're the highest bidder";
    if (L.folded?.[myTeam]) return 'You folded';
    return bidBlock(team, p, nb, settings);
  }, [myTeam, isBidding, L, team, p, nb, settings]);

  const bid = async (amount) => {
    const r = await placeBid(code, S, myTeam, amount);
    if (!r.ok) toast(r.why);
    setJumpOpen(false);
  };

  // Space to bid.
  useEffect(() => {
    const k = (e) => {
      if (e.code !== 'Space' || ['INPUT', 'TEXTAREA', 'SELECT'].includes(e.target.tagName)) return;
      e.preventDefault();
      if (!block) bid(nb);
    };
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  });

  if (!L) return <div className="panel p-8 text-center text-fg-3">Waiting for the auctioneer</div>;

  const h = arr(L.history);
  const warTeams = [...new Set(h.slice().reverse().map((x) => x.t))].slice(0, 2);
  const going = L.stage === 'bidding' && L.team && !L.paused ? (remain <= 1000 ? 'Going…' : remain <= 2000 ? 'Going twice' : remain <= 3000 ? 'Going once' : null) : null;
  const upNext = list.slice((L.idx ?? 0) + 1, (L.idx ?? 0) + 4).map((id) => PLAYER_MAP[id]);
  const jumps = [nb, nb + increment(nb), nb + 50, nb + 100, nb + 200].filter((v, i, a) => a.indexOf(v) === i);
  const leadTeam = L.stage === 'result' ? L.result?.team : L.team;

  return (
    <div className="relative">
      {/* Commentary */}
      <div className="mb-3 flex min-h-6 items-center gap-2 text-[14px] text-fg-2" aria-live="polite">
        <span className="size-1.5 shrink-0 rounded-full bg-brass" />
        <span className="truncate">{commentary(L, p)}</span>
      </div>

      {L.stage === 'transition' && (
        <div className="panel flex min-h-[340px] flex-col items-center justify-center p-8 text-center animate-fade">
          <div className="label">Next set</div>
          <div className="mt-2 font-display text-[44px] font-semibold leading-none sm:text-[60px]">{L.set}</div>
          <div className="mt-3 text-fg-2">{L.count} players · first one in {Math.max(0, Math.ceil((L.until - t) / 1000))}s</div>
        </div>
      )}

      {L.stage === 'complete' && <CompleteCard />}

      {p && !['transition', 'complete'].includes(L.stage) && (
        <Spotlight p={{ ...p, basePriceOverride: L.base }} lead={leadTeam} onInfo={() => onPlayerInfo?.(p)}
          stamp={L.stage === 'result' ? L.result?.type : null} soldTo={L.result?.team} soldPrice={L.result?.price}>
          {/* Bid board */}
          <div className="mt-5 flex items-center gap-4 rounded-xl border border-line bg-ink-900/70 p-3 sm:p-4">
            {L.stage !== 'result' && <TimerRing remain={L.paused ? (L.endsAt - L.pausedAt) : remain} total={total} />}
            <div className="min-w-0 flex-1">
              <div className="label">{L.team ? 'Highest bid' : 'Base price'}</div>
              <div className="num font-display text-[34px] font-semibold leading-none sm:text-[40px]">{fmt(L.team ? L.amount : L.base)}</div>
              <div className="mt-1 h-5 text-[13px]">
                {going ? <span className="font-medium text-bad">{going}</span> : L.team ? <span className="text-fg-2">by {S.members?.[S.teams?.[L.team]?.owner]?.name || 'AI bot'}</span> : <span className="text-fg-3">No bids yet</span>}
              </div>
            </div>
            {L.team && (
              <div className="flex flex-col items-center gap-1" style={{ '--tc': TEAMS[L.team].color }}>
                <Paddle team={L.team} size={48} />
              </div>
            )}
          </div>

          {/* Bidding war + ticker */}
          {h.length > 0 && L.stage !== 'result' && (
            <div className="mt-3 flex items-center justify-between gap-3">
              <div className="no-scrollbar flex min-w-0 gap-1.5 overflow-x-auto">
                {h.slice(-5).reverse().map((b, i) => (
                  <span key={i} className={`flex h-7 shrink-0 items-center gap-1.5 rounded-md border border-line pl-1 pr-2 text-[12px] ${i === 0 ? 'bg-ink-800 text-fg' : 'text-fg-3'}`}>
                    <Paddle team={b.t} size={16} /><span className="num font-mono">{fmt(b.a)}</span>
                  </span>
                ))}
              </div>
              {warTeams.length === 2 && h.length >= 3 && (
                <span className="hidden shrink-0 items-center gap-1.5 text-[12px] text-fg-3 sm:flex"><Paddle team={warTeams[0]} size={18} />vs<Paddle team={warTeams[1]} size={18} /></span>
              )}
            </div>
          )}

          {['rtm', 'counter', 'match'].includes(L.stage) && (
            <div className="mt-3 flex items-center gap-3 rounded-xl border border-brass/40 bg-brass/10 px-3 py-2.5 text-[13px]">
              <Paddle team={L.rtm.team} size={24} />
              <span className="flex-1 text-fg">
                {L.stage === 'rtm' && `Right to match: ${L.rtm.team} deciding`}
                {L.stage === 'counter' && `${L.rtm.team} used the RTM. ${L.team} may raise once`}
                {L.stage === 'match' && `${L.team} raised to ${fmt(L.amount)}. ${L.rtm.team} to match or pass`}
              </span>
            </div>
          )}

          {/* Folded */}
          {L.folded && L.stage === 'bidding' && (
            <div className="mt-3 flex flex-wrap items-center gap-1.5 text-[12px] text-fg-3">
              Out: {Object.keys(L.folded).map((f) => <Paddle key={f} team={f} size={18} dim />)}
            </div>
          )}
        </Spotlight>
      )}

      {L.paused && (
        <div className="absolute inset-x-0 top-10 z-30 mx-auto w-fit rounded-xl border border-line-2 bg-ink-950/95 px-5 py-3 text-center shadow-xl animate-rise">
          <div className="flex items-center justify-center gap-2 font-display text-[22px] font-semibold"><LuPause size={18} /> Break</div>
          <div className="text-[13px] text-fg-2">{L.breakMsg || 'The auctioneer paused the auction'}</div>
        </div>
      )}

      {/* Controls */}
      {myTeam && p && L.stage !== 'complete' && L.stage !== 'transition' && (
        <div className="mt-4">
          <div className="flex gap-2">
            <button className="btn btn-primary h-14 flex-1 text-[17px]" disabled={!!block} onClick={() => bid(nb)}>
              {block && block !== 'Bidding closed' ? block : <>Bid {fmt(nb)} <span className="kbd ml-1 hidden border-black/20 bg-black/10 text-[#17120a] sm:inline-flex">Space</span></>}
            </button>
            <button className="btn h-14 px-3" disabled={!!block} onClick={() => setJumpOpen((o) => !o)} aria-label="Jump bid" aria-expanded={jumpOpen}>
              <LuChevronDown size={18} className={`transition-transform ${jumpOpen ? 'rotate-180' : ''}`} />
            </button>
            <button className="btn h-14" disabled={!isBidding || L.team === myTeam || !!L.folded?.[myTeam]} onClick={() => fold(code, L, myTeam)} title="Signal you're out">
              <LuHand size={16} /> <span className="hidden sm:inline">Fold</span>
            </button>
          </div>
          {jumpOpen && !block && (
            <div className="panel mt-2 p-3 animate-rise">
              <div className="label mb-2">Raise the paddle</div>
              <div className="flex flex-wrap gap-2">
                {jumps.map((v) => <button key={v} className="btn btn-sm num" disabled={!!bidBlock(team, p, v, settings)} onClick={() => bid(v)}>{fmt(v)}</button>)}
              </div>
              <form className="mt-3 flex gap-2" onSubmit={(e) => { e.preventDefault(); const v = Math.round(parseFloat(custom) * 100); if (v >= nb) bid(v); else toast(`Minimum is ${fmt(nb)}`); }}>
                <input className="field h-9" inputMode="decimal" placeholder="Amount in crore, e.g. 7.5" value={custom} onChange={(e) => setCustom(e.target.value)} />
                <button className="btn btn-sm h-9">Bid</button>
              </form>
            </div>
          )}
          {team && <div className="mt-2 text-[12px] text-fg-3">You can spend up to <span className="num font-mono text-fg-2">{fmt(maxAffordable(team, settings))}</span> on one player and still fill 18 slots</div>}
        </div>
      )}

      {/* Reactions */}
      <div className="relative mt-4 flex items-center justify-between gap-3">
        <Reactions />
        <div className="flex gap-1">
          {EMOJIS.map((e) => (
            <button key={e} className="flex size-10 items-center justify-center rounded-lg text-[20px] transition-[background-color,transform] hover:bg-ink-800 active:scale-95" onClick={() => { sendReaction(code, S, e); sfx.pop(); }} aria-label={`React ${e}`}>{e}</button>
          ))}
        </div>
      </div>

      {/* Up next */}
      {upNext.length > 0 && L.stage !== 'complete' && (
        <div className="mt-4">
          <div className="label mb-2">Up next</div>
          <div className="grid grid-cols-3 gap-2">
            {upNext.map((u) => (
              <button key={u.id} className="raised rounded-xl p-3 text-left transition-colors hover:bg-ink-700" onClick={() => onPlayerInfo?.(u)}>
                <div className="truncate text-[13px] font-medium">{u.name}</div>
                <div className="mt-0.5 truncate text-[12px] text-fg-3">{u.role} · {fmt(S.queue?.reduced?.[u.id] ?? u.basePrice)}</div>
              </button>
            ))}
          </div>
        </div>
      )}
      {compactFeed}
      <RtmModals />
    </div>
  );
}

function CompleteCard() {
  const { S, isHost } = useRoom();
  const unsold = Object.values(S.players || {}).filter((v) => v.status === 'unsold').length;
  return (
    <div className="panel flex min-h-[300px] flex-col items-center justify-center p-8 text-center">
      <div className="font-display text-[40px] font-semibold leading-none">That's the list</div>
      <p className="mt-3 max-w-sm text-fg-2">
        {unsold} players went unsold. {isHost ? 'Run a re-entry or accelerated round from the auctioneer panel, or finish the auction.' : 'Waiting for the auctioneer to call the next round or wrap up.'}
      </p>
    </div>
  );
}

function RtmModals() {
  const { code, S, settings, myTeam } = useRoom();
  const L = S.live;
  const t = useNow(250);
  const [raise, setRaise] = useState('');
  if (!L || !myTeam || !['rtm', 'counter', 'match'].includes(L.stage)) return null;
  const p = PLAYER_MAP[L.pid];
  const secs = Math.max(0, Math.ceil((L.rtm.endsAt - t) / 1000));
  if (L.stage === 'rtm' && L.rtm.team === myTeam && !L.rtm.decision) {
    return (
      <Modal open title="Right to match" footer={
        <div className="flex gap-2"><button className="btn flex-1" onClick={() => rtmDecide(code, L, 'pass')}>Let him go</button><button className="btn btn-primary flex-1" onClick={() => rtmDecide(code, L, 'use')}>Use RTM card</button></div>}>
        <p className="text-fg-2">{p.name} played for you last season. Bidding ended with</p>
        <div className="my-4 flex items-center gap-3"><Paddle team={L.team} size={40} /><span className="num font-display text-[36px] font-semibold">{fmt(L.amount)}</span></div>
        <p className="text-[13px] text-fg-3">If you use it, {L.team} get one chance to raise. You then match their final price or pass. You have {S.teams[myTeam].rtm} RTM cards. {secs}s to decide.</p>
      </Modal>
    );
  }
  if (L.stage === 'counter' && L.team === myTeam && L.rtm.raise == null) {
    const opts = [L.amount + increment(L.amount), Math.round(L.amount * 1.1 / 5) * 5, Math.round(L.amount * 1.25 / 5) * 5].filter((v, i, a) => v > L.amount && a.indexOf(v) === i);
    const send = (v) => { if (bidBlock(S.teams[myTeam], p, v, settings)) return; counterDecide(code, L, v); };
    return (
      <Modal open title={`${L.rtm.team} used the RTM`} footer={
        <div className="flex gap-2"><button className="btn flex-1" onClick={() => counterDecide(code, L, 0)}>Keep {fmt(L.amount)}</button></div>}>
        <p className="text-fg-2">One last chance to raise for {p.name}. If you keep your bid, {L.rtm.team} get him at {fmt(L.amount)}. {secs}s left.</p>
        <div className="mt-4 flex flex-wrap gap-2">{opts.map((v) => <button key={v} className="btn num" disabled={!!bidBlock(S.teams[myTeam], p, v, settings)} onClick={() => send(v)}>Raise to {fmt(v)}</button>)}</div>
        <form className="mt-3 flex gap-2" onSubmit={(e) => { e.preventDefault(); const v = Math.round(parseFloat(raise) * 100); if (v > L.amount) send(v); }}>
          <input className="field h-10" inputMode="decimal" placeholder="Final amount in crore" value={raise} onChange={(e) => setRaise(e.target.value)} />
          <button className="btn btn-primary h-10">Raise</button>
        </form>
      </Modal>
    );
  }
  if (L.stage === 'match' && L.rtm.team === myTeam && !L.rtm.match) {
    return (
      <Modal open title="Match the final price?" footer={
        <div className="flex gap-2"><button className="btn flex-1" onClick={() => matchDecide(code, L, 'no')}>Pass</button><button className="btn btn-primary flex-1" onClick={() => matchDecide(code, L, 'yes')}>Match {fmt(L.amount)}</button></div>}>
        <p className="text-fg-2">{L.team} raised to</p>
        <div className="my-4 flex items-center gap-3"><Paddle team={L.team} size={40} /><span className="num font-display text-[36px] font-semibold">{fmt(L.amount)}</span></div>
        <p className="text-[13px] text-fg-3">Match it and {p.name} is yours, using one RTM card. {secs}s left.</p>
      </Modal>
    );
  }
  return null;
}

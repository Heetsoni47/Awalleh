import { useEffect, useMemo, useRef, useState } from 'react';
import { LuDownload, LuImage, LuShare2, LuRotateCcw, LuArrowLeftRight, LuLogOut, LuTrophy } from 'react-icons/lu';
import { useRoom } from './Room';
import { resetRoom, openTrades, closeTrades, proposeTrade, acceptTrade, rejectTrade, tradeProblem } from '../lib/engine';
import { PLAYERS, PLAYER_MAP } from '../data/playersData';
import { TEAMS, fmt, squadOf, overseasCount, teamStrength, roleSpend, autoXI, arr } from '../lib/rules';
import { Paddle, Logo, Modal, RoleTag, useNow, useToast, Empty } from './ui';
import { SquadPanel, soldList, stealOf } from './Panels';
import { sfx } from '../lib/sound';

function Confetti() {
  const ref = useRef(null);
  useEffect(() => {
    const c = ref.current; if (!c) return;
    const ctx = c.getContext('2d');
    const W = (c.width = innerWidth), H = (c.height = innerHeight);
    const cols = ['#e3a948', '#f0c374', '#eef0f5', '#4cc38a', '#5b9bff', '#ff5a62'];
    const ps = Array.from({ length: 160 }, () => ({ x: Math.random() * W, y: -20 - Math.random() * H * 0.6, vx: (Math.random() - 0.5) * 2, vy: 2 + Math.random() * 3, r: Math.random() * 6.28, vr: (Math.random() - 0.5) * 0.2, c: cols[(Math.random() * cols.length) | 0], w: 6 + Math.random() * 6 }));
    let raf, start = performance.now();
    const step = (t) => {
      ctx.clearRect(0, 0, W, H);
      ps.forEach((p) => { p.x += p.vx; p.y += p.vy; p.r += p.vr; ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.r); ctx.fillStyle = p.c; ctx.fillRect(-p.w / 2, -2, p.w, 4); ctx.restore(); });
      if (t - start < 5000) raf = requestAnimationFrame(step); else ctx.clearRect(0, 0, W, H);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, []);
  return <canvas ref={ref} className="pointer-events-none fixed inset-0 z-50" aria-hidden />;
}

export function useSummary() {
  const { S, settings } = useRoom();
  return useMemo(() => {
    const teams = Object.keys(S.teams || {}).map((t) => {
      const tm = S.teams[t];
      const sq = squadOf(tm);
      const spent = settings.purse - tm.purse;
      const ratingSum = sq.reduce((a, s) => a + s.p.rating, 0);
      return {
        t, tm, sq, spent, left: tm.purse, n: sq.length, os: overseasCount(tm), strength: teamStrength(tm),
        value: spent ? ratingSum / (spent / 100) : 0, owner: tm.owner === 'BOT' ? 'AI bot' : S.members?.[tm.owner]?.name || 'Manager', roles: roleSpend(tm),
      };
    });
    const sold = soldList(S).concat(Object.entries(S.players || {}).filter(([, v]) => v.status === 'retained').map(([pid, v]) => ({ p: PLAYER_MAP[pid], ...v })));
    const top10 = [...sold].sort((a, b) => b.price - a.price).slice(0, 10);
    const by = (k, dir = -1) => [...teams].sort((a, b) => (b[k] - a[k]) * -dir)[0];
    const unsoldPlayers = PLAYERS.filter((p) => S.players?.[p.id]?.status === 'unsold');
    return {
      teams, top10, steal: stealOf(soldList(S)), unsoldXI: autoXI(unsoldPlayers),
      awards: teams.length ? [
        ['Biggest spender', by('spent'), (x) => fmt(x.spent)],
        ['Smartest buyer', by('value'), (x) => `${x.value.toFixed(1)} rating pts per Cr`],
        ['Most expensive player', top10[0] && { t: top10[0].team, label: top10[0].p.name }, () => fmt(top10[0]?.price)],
        ['Strongest playing XI', by('strength'), (x) => `${x.strength}/100`],
        ['Biggest purse left', by('left'), (x) => fmt(x.left)],
      ] : [],
    };
  }, [S, settings]);
}

function exportCSV(sum) {
  const rows = [['Team', 'Owner', 'Player', 'Role', 'Country', 'Overseas', 'Price (Cr)', 'How']];
  sum.teams.forEach((x) => x.sq.forEach((s) => rows.push([x.t, x.owner, s.p.name, s.p.role, s.p.country, s.p.isOverseas ? 'Yes' : 'No', (s.price / 100).toFixed(2), s.how])));
  rows.push([]); rows.push(['Team', 'Owner', 'Spent (Cr)', 'Remaining (Cr)', 'Players', 'Overseas', 'Strength']);
  sum.teams.forEach((x) => rows.push([x.t, x.owner, (x.spent / 100).toFixed(2), (x.left / 100).toFixed(2), x.n, x.os, x.strength]));
  download('walleh-auction-squads.csv', rows.map((r) => r.map((c) => `"${String(c ?? '').replace(/"/g, '""')}"`).join(',')).join('\n'), 'text/csv');
}
function exportJSON(sum) {
  const data = sum.teams.map((x) => ({ team: x.t, owner: x.owner, spentCr: x.spent / 100, remainingCr: x.left / 100, players: x.sq.map((s) => ({ name: s.p.name, role: s.p.role, country: s.p.country, priceCr: s.price / 100, how: s.how })), strength: x.strength }));
  download('walleh-auction-squads.json', JSON.stringify(data, null, 2), 'application/json');
}
function download(name, content, type) {
  const url = typeof content === 'string' ? URL.createObjectURL(new Blob([content], { type })) : content;
  const a = Object.assign(document.createElement('a'), { href: url, download: name });
  document.body.appendChild(a); a.click(); a.remove();
}
function summaryImage(sum, code) {
  const W = 1080, rowH = 84, H = 260 + sum.teams.length * rowH + 140;
  const c = Object.assign(document.createElement('canvas'), { width: W, height: H });
  const g = c.getContext('2d');
  g.fillStyle = '#0b0d14'; g.fillRect(0, 0, W, H);
  g.fillStyle = '#e3a948'; g.font = '600 30px Inter, sans-serif'; g.fillText('A Walleh Auction', 64, 84);
  g.fillStyle = '#eef0f5'; g.font = '600 64px "Barlow Condensed", sans-serif'; g.fillText('Final squads', 64, 160);
  g.fillStyle = '#7a8296'; g.font = '400 22px Inter, sans-serif'; g.fillText(`Room ${code} · ${new Date().toLocaleDateString()}`, 64, 200);
  const cols = [[64, 'Team'], [420, 'Spent'], [580, 'Left'], [740, 'Players'], [880, 'Strength']];
  g.font = '400 20px Inter, sans-serif'; g.fillStyle = '#7a8296';
  cols.forEach(([x, l]) => g.fillText(l, x, 248));
  [...sum.teams].sort((a, b) => b.strength - a.strength).forEach((x, i) => {
    const y = 270 + i * rowH;
    g.fillStyle = i % 2 ? '#0b0d14' : '#11141c'; g.fillRect(40, y, W - 80, rowH - 8);
    const T = TEAMS[x.t];
    g.fillStyle = T.color; g.beginPath(); g.arc(92, y + 38, 26, 0, Math.PI * 2); g.fill();
    g.fillStyle = T.text; g.font = '600 18px "Barlow Condensed", sans-serif'; g.textAlign = 'center'; g.fillText(T.short, 92, y + 44); g.textAlign = 'left';
    g.fillStyle = '#eef0f5'; g.font = '500 24px Inter, sans-serif'; g.fillText(x.owner.slice(0, 16), 136, y + 46);
    g.font = '500 26px "JetBrains Mono", monospace';
    g.fillText(fmt(x.spent).replace('₹', ''), 420, y + 46); g.fillStyle = '#e3a948'; g.fillText(fmt(x.left).replace('₹', ''), 580, y + 46);
    g.fillStyle = '#eef0f5'; g.fillText(`${x.n} (${x.os} OS)`, 740, y + 46); g.fillText(String(x.strength), 900, y + 46);
  });
  g.fillStyle = '#7a8296'; g.font = '400 20px Inter, sans-serif';
  if (sum.top10[0]) g.fillText(`Top buy: ${sum.top10[0].p.name} to ${sum.top10[0].team} for ${fmt(sum.top10[0].price)}`, 64, H - 70);
  return c;
}

function shareText(sum, code) {
  const lines = ['A Walleh Auction: final results', ''];
  [...sum.teams].sort((a, b) => b.strength - a.strength).forEach((x, i) => lines.push(`${i + 1}. ${x.t} (${x.owner}): ${x.n} players, ${fmt(x.left)} left, strength ${x.strength}`));
  if (sum.top10[0]) lines.push('', `Top buy: ${sum.top10[0].p.name} ${fmt(sum.top10[0].price)} to ${sum.top10[0].team}`);
  if (sum.steal) lines.push(`Steal: ${sum.steal.p.name} ${fmt(sum.steal.price)} to ${sum.steal.team}`);
  lines.push('', `Room ${code}: ${location.origin}${location.pathname}?room=${code}`);
  return lines.join('\n');
}

export default function Summary() {
  const { code, S, isHost, myTeam, onExit } = useRoom();
  const sum = useSummary();
  const toast = useToast();
  const [view, setView] = useState(myTeam || sum.teams[0]?.t);
  const [tradeOpen, setTradeOpen] = useState(false);
  const t = useNow(1000);
  useEffect(() => { sfx.fanfare(); }, []);
  const trade = S.meta?.phase === 'trade';
  const tradeLeft = trade ? Math.max(0, S.meta.tradeEndsAt - t) : 0;
  const share = async () => {
    const text = shareText(sum, code);
    if (navigator.share) { try { await navigator.share({ title: 'A Walleh Auction results', text }); return; } catch {} }
    try { await navigator.clipboard.writeText(text); toast('Results copied. Paste them into WhatsApp or Discord'); } catch { toast('Could not copy'); }
  };
  const image = () => { const c = summaryImage(sum, code); download('walleh-auction-results.png', c.toDataURL('image/png')); };

  return (
    <div className="min-h-dvh">
      <Confetti />
      <header className="sticky top-0 z-30 border-b border-line bg-ink-900/90 backdrop-blur">
        <div className="mx-auto flex h-14 max-w-6xl items-center justify-between gap-3 px-4 sm:px-6">
          <Logo small />
          <div className="flex items-center gap-1">
            {isHost && <button className="btn btn-sm" onClick={() => confirm('Reset the room for a new auction? Squads will be cleared.') && resetRoom(code, S)}><LuRotateCcw size={16} /><span className="hidden sm:inline">Play again</span></button>}
            <button className="btn btn-ghost btn-sm" onClick={onExit}><LuLogOut size={16} /><span className="hidden sm:inline">Leave</span></button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl space-y-6 px-4 py-6 sm:px-6 lg:py-10">
        <section className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <div className="label">Room {code}</div>
            <h1 className="mt-1 font-display text-[44px] font-semibold leading-none sm:text-[56px]">The hammer has fallen</h1>
            <p className="mt-2 text-fg-2">{sum.teams.reduce((a, x) => a + x.n, 0)} players bought for {fmt(sum.teams.reduce((a, x) => a + x.spent, 0))} across {sum.teams.length} franchises</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <button className="btn btn-sm" onClick={share}><LuShare2 size={16} /> Share results</button>
            <button className="btn btn-sm" onClick={image}><LuImage size={16} /> Image</button>
            <button className="btn btn-sm" onClick={() => exportCSV(sum)}><LuDownload size={16} /> CSV</button>
            <button className="btn btn-sm" onClick={() => exportJSON(sum)}><LuDownload size={16} /> JSON</button>
          </div>
        </section>

        {/* Trade window */}
        {(trade || isHost) && (
          <section className={`panel flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between ${trade ? 'border-brass/40' : ''}`}>
            <div className="flex items-center gap-3">
              <LuArrowLeftRight size={18} className="text-fg-2" />
              {trade ? <span>Trade window open · <span className="num font-mono text-brass">{Math.floor(tradeLeft / 60000)}:{String(Math.floor((tradeLeft % 60000) / 1000)).padStart(2, '0')}</span> left</span> : <span className="text-fg-2">Open a 5-minute window for player and cash trades</span>}
            </div>
            <div className="flex gap-2">
              {trade && myTeam && <button className="btn btn-primary btn-sm" onClick={() => setTradeOpen(true)}>Propose a trade</button>}
              {isHost && (trade ? <button className="btn btn-sm" onClick={() => closeTrades(code)}>Close window</button> : <button className="btn btn-sm" onClick={() => openTrades(code)}>Open trade window</button>)}
            </div>
          </section>
        )}
        {trade && <TradeList />}

        {/* Awards */}
        <section>
          <h2 className="mb-3 flex items-center gap-2 text-[15px] font-medium"><LuTrophy size={16} className="text-brass" /> Awards</h2>
          <div className="grid grid-cols-2 gap-2 md:grid-cols-5">
            {sum.awards.map(([label, x, val]) => x && (
              <div key={label} className="panel p-4">
                <div className="label">{label}</div>
                <div className="mt-3 flex items-center gap-2"><Paddle team={x.t} size={28} /><span className="truncate text-[14px] font-medium">{x.label || x.owner}</span></div>
                <div className="num mt-2 font-mono text-[13px] text-brass">{val(x)}</div>
              </div>
            ))}
          </div>
        </section>

        {/* Grand summary */}
        <section className="panel overflow-hidden">
          <div className="border-b border-line px-5 py-4"><h2 className="text-[15px] font-medium">Grand summary</h2></div>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[640px] text-[13px]">
              <thead className="text-left text-fg-3">
                <tr className="border-b border-line">
                  {['Team', 'Spent', 'Remaining', 'Players', 'Overseas', 'Strength', 'Spend by role'].map((h, i) => <th key={h} className={`px-5 py-2.5 font-normal ${i > 0 && i < 6 ? 'text-right' : ''}`}>{h}</th>)}
                </tr>
              </thead>
              <tbody>
                {[...sum.teams].sort((a, b) => b.strength - a.strength).map((x) => (
                  <tr key={x.t} className={`border-b border-line last:border-0 ${x.t === myTeam ? 'bg-ink-800/60' : ''}`}>
                    <td className="px-5 py-3"><span className="flex items-center gap-2.5"><Paddle team={x.t} size={24} />{x.owner}</span></td>
                    <td className="num whitespace-nowrap px-5 py-3 text-right font-mono">{fmt(x.spent)}</td>
                    <td className="num whitespace-nowrap px-5 py-3 text-right font-mono text-brass">{fmt(x.left)}</td>
                    <td className="num whitespace-nowrap px-5 py-3 text-right font-mono">{x.n}</td>
                    <td className="num whitespace-nowrap px-5 py-3 text-right font-mono">{x.os}</td>
                    <td className="num whitespace-nowrap px-5 py-3 text-right font-mono">{x.strength}</td>
                    <td className="w-48 px-5 py-3"><RoleSpendBar roles={x.roles} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="flex flex-wrap gap-4 border-t border-line px-5 py-3 text-[12px] text-fg-3">
            {ROLE_COLORS.map(([r, c]) => <span key={r} className="flex items-center gap-1.5"><span className="size-2 rounded-sm" style={{ background: c }} />{r}</span>)}
          </div>
        </section>

        <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_380px] [&>*]:min-w-0">
          {/* Squad viewer */}
          <section className="panel p-5">
            <div className="no-scrollbar -mx-1 mb-4 flex gap-1 overflow-x-auto px-1">
              {sum.teams.map((x) => (
                <button key={x.t} onClick={() => setView(x.t)} className={`flex h-10 shrink-0 items-center gap-2 rounded-lg px-2.5 text-[13px] transition-colors ${view === x.t ? 'bg-ink-700 text-fg' : 'text-fg-2 hover:bg-ink-800'}`}>
                  <Paddle team={x.t} size={20} />{x.t}
                </button>
              ))}
            </div>
            {view && <SquadPanel team={view} />}
          </section>

          <div className="space-y-6">
            <section className="panel p-5">
              <h2 className="mb-3 text-[15px] font-medium">Top 10 buys</h2>
              <ol className="space-y-1">
                {sum.top10.map((x, i) => (
                  <li key={x.p.id} className="flex items-center gap-3 py-1.5">
                    <span className="num w-5 font-mono text-[12px] text-fg-3">{i + 1}</span>
                    <Paddle team={x.team} size={20} />
                    <span className="min-w-0 flex-1 truncate text-[13px]">{x.p.name}</span>
                    <span className="num font-mono text-[13px] text-brass">{fmt(x.price)}</span>
                  </li>
                ))}
              </ol>
              {sum.steal && <p className="mt-3 border-t border-line pt-3 text-[13px] text-fg-2">Steal of the night: <span className="text-fg">{sum.steal.p.name}</span> to {sum.steal.team} for {fmt(sum.steal.price)}</p>}
            </section>
            <section className="panel p-5">
              <h2 className="text-[15px] font-medium">Unsold XI</h2>
              <p className="mb-3 text-[12px] text-fg-3">The best side nobody wanted</p>
              {!sum.unsoldXI.length && <Empty>Everyone found a home</Empty>}
              <ol className="space-y-1">
                {sum.unsoldXI.map((p, i) => (
                  <li key={p.id} className="flex items-center gap-3 py-1">
                    <span className="num w-5 font-mono text-[12px] text-fg-3">{i + 1}</span>
                    <span className="min-w-0 flex-1 truncate text-[13px]">{p.name}</span>
                    <RoleTag p={p} /><span className="num w-6 text-right font-mono text-[12px] text-fg-3">{p.rating}</span>
                  </li>
                ))}
              </ol>
            </section>
          </div>
        </div>
      </main>
      {tradeOpen && <TradeModal onClose={() => setTradeOpen(false)} />}
    </div>
  );
}

const ROLE_COLORS = [['Batters', '#eef0f5'], ['Wicketkeepers', '#a3a9b8'], ['All-Rounders', '#e3a948'], ['Bowlers', '#5a6275']];
function RoleSpendBar({ roles }) {
  const total = Object.values(roles).reduce((a, b) => a + b, 0) || 1;
  return (
    <div className="flex h-2 w-full overflow-hidden rounded-full bg-ink-800" title={ROLE_COLORS.map(([r]) => `${r}: ${fmt(roles[r])}`).join(' · ')}>
      {ROLE_COLORS.map(([r, c]) => <div key={r} style={{ width: `${(roles[r] / total) * 100}%`, background: c }} />)}
    </div>
  );
}

function TradeList() {
  const { code, S, myTeam } = useRoom();
  const toast = useToast();
  const trades = Object.entries(S.trades || {}).sort(([, a], [, b]) => b.ts - a.ts);
  if (!trades.length) return null;
  return (
    <section className="panel divide-y divide-line">
      {trades.map(([id, tr]) => {
        const names = (pids) => arr(pids).map((p) => PLAYER_MAP[p].name).join(', ') || 'nothing';
        const problem = tr.status === 'pending' ? tradeProblem(S, tr) : null;
        return (
          <div key={id} className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center">
            <div className="flex items-center gap-2"><Paddle team={tr.from} size={24} /><LuArrowLeftRight size={14} className="text-fg-3" /><Paddle team={tr.to} size={24} /></div>
            <div className="min-w-0 flex-1 text-[13px] text-fg-2">
              {tr.from} give <span className="text-fg">{names(tr.give)}</span>{tr.cash > 0 ? ` + ${fmt(tr.cash)}` : ''} for <span className="text-fg">{names(tr.get)}</span>{tr.cash < 0 ? ` + ${fmt(-tr.cash)}` : ''}
              {problem && <span className="ml-2 text-warn">{problem}</span>}
            </div>
            {tr.status === 'pending' && tr.to === myTeam ? (
              <div className="flex gap-2">
                <button className="btn btn-sm" onClick={() => rejectTrade(code, id)}>Decline</button>
                <button className="btn btn-primary btn-sm" disabled={!!problem} onClick={async () => { const e = await acceptTrade(code, S, id, tr); e && toast(e); }}>Accept</button>
              </div>
            ) : <span className={`text-[12px] ${tr.status === 'accepted' ? 'text-good' : tr.status === 'rejected' ? 'text-fg-3' : 'text-fg-2'}`}>{tr.status === 'pending' ? 'Waiting' : tr.status === 'accepted' ? 'Accepted' : 'Declined'}</span>}
          </div>
        );
      })}
    </section>
  );
}

function TradeModal({ onClose }) {
  const { code, S, myTeam } = useRoom();
  const toast = useToast();
  const others = Object.keys(S.teams || {}).filter((t) => t !== myTeam);
  const [to, setTo] = useState(others[0]);
  const [give, setGive] = useState([]);
  const [get, setGet] = useState([]);
  const [cash, setCash] = useState('');
  const mine = squadOf(S.teams[myTeam]);
  const theirs = to ? squadOf(S.teams[to]) : [];
  const flip = (arrState, set, pid) => set(arrState.includes(pid) ? arrState.filter((x) => x !== pid) : [...arrState, pid]);
  const tr = { from: myTeam, to, give, get, cash: Math.round((parseFloat(cash) || 0) * 100) };
  const problem = (give.length || get.length || tr.cash) ? tradeProblem(S, tr) : 'Pick at least one player or some cash';
  const Col = ({ title, list, sel, set }) => (
    <div className="min-w-0">
      <div className="label mb-2">{title}</div>
      <ul className="max-h-64 space-y-1 overflow-y-auto">
        {list.map((s) => (
          <li key={s.pid}><button onClick={() => flip(sel, set, s.pid)} className={`flex w-full items-center gap-2 rounded-lg border px-2 py-1.5 text-left text-[13px] ${sel.includes(s.pid) ? 'border-brass/60 bg-ink-800' : 'border-line'}`}><span className="min-w-0 flex-1 truncate">{s.p.name}</span><span className="num font-mono text-[11px] text-fg-3">{fmt(s.price)}</span></button></li>
        ))}
      </ul>
    </div>
  );
  return (
    <Modal open onClose={onClose} wide title="Propose a trade" footer={
      <div className="flex items-center justify-between gap-3">
        <span className="text-[13px] text-warn">{problem}</span>
        <button className="btn btn-primary" disabled={!!problem} onClick={() => { proposeTrade(code, tr); toast('Trade offer sent'); onClose(); }}>Send offer</button>
      </div>}>
      <div className="mb-4 flex flex-wrap gap-2">
        {others.map((t) => <button key={t} onClick={() => { setTo(t); setGet([]); }} className={`flex h-10 items-center gap-2 rounded-lg border px-2.5 text-[13px] ${to === t ? 'border-brass bg-ink-800' : 'border-line'}`}><Paddle team={t} size={20} />{t}</button>)}
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <Col title={`You give (${myTeam})`} list={mine} sel={give} set={setGive} />
        <Col title={`You get (${to})`} list={theirs} sel={get} set={setGet} />
      </div>
      <label className="label mt-4 block">Cash you add, in crore (negative to ask for cash)</label>
      <input className="field mt-1 h-10 w-40" inputMode="decimal" value={cash} onChange={(e) => setCash(e.target.value)} placeholder="0" />
    </Modal>
  );
}

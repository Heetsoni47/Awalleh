import { useEffect, useState, createContext, useContext } from 'react';
import { LuX } from 'react-icons/lu';
import { TEAMS } from '../lib/rules';
import { now } from '../lib/db';

/** Signature: every franchise is a round bid paddle in its colours. */
export function Paddle({ team, size = 28, dim = false, className = '' }) {
  const t = TEAMS[team];
  if (!t) return <span className={`inline-block rounded-full bg-ink-700 ${className}`} style={{ width: size, height: size }} />;
  const fs = size <= 22 ? size * 0.34 : size * 0.3;
  return (
    <span className={`relative inline-flex shrink-0 items-center justify-center ${className}`} style={{ width: size, height: size * 1.12, opacity: dim ? 0.4 : 1 }} title={t.name} aria-label={t.name}>
      <span className="absolute bottom-0 left-1/2 -translate-x-1/2 rounded-b-sm" style={{ width: Math.max(3, size * 0.16), height: size * 0.3, background: t.accent === '#000000' || t.accent === '#1a1a1a' ? '#3a3a3a' : t.accent }} />
      <span
        className="absolute top-0 flex items-center justify-center rounded-full font-display font-semibold leading-none"
        style={{ width: size, height: size, background: t.color, color: t.text, fontSize: fs, boxShadow: 'inset 0 -2px 0 rgb(0 0 0 / 0.25), inset 0 1px 0 rgb(255 255 255 / 0.25)' }}
      >
        {t.short}
      </span>
    </span>
  );
}

export function Avatar({ name = '?', color = '#7a8296', size = 28 }) {
  const initials = name.split(/\s+/).map((w) => w[0]).join('').slice(0, 2).toUpperCase();
  return (
    <span className="inline-flex shrink-0 items-center justify-center rounded-full font-medium text-ink-900" style={{ width: size, height: size, background: color, fontSize: size * 0.4 }}>
      {initials}
    </span>
  );
}

export function PresenceDot({ m }) {
  const [, tick] = useState(0);
  useEffect(() => { const i = setInterval(() => tick((x) => x + 1), 5000); return () => clearInterval(i); }, []);
  let c = 'bg-fg-3', label = 'Offline';
  if (m?.online) { c = 'bg-good'; label = 'Online'; }
  else if (m?.lastSeen && now() - m.lastSeen < 60000) { c = 'bg-warn'; label = 'Reconnecting'; }
  return <span className={`inline-block size-2 shrink-0 rounded-full ${c}`} title={label} aria-label={label} />;
}

const CC = { India: 'IND', Australia: 'AUS', England: 'ENG', 'South Africa': 'RSA', 'New Zealand': 'NZ', 'West Indies': 'WI', Afghanistan: 'AFG', 'Sri Lanka': 'SL', Bangladesh: 'BAN', Zimbabwe: 'ZIM' };
export const CountryTag = ({ country }) => <span className="chip font-mono" title={country}>{CC[country] || country.slice(0, 3).toUpperCase()}</span>;
const ROLE_SHORT = { Batter: 'BAT', Bowler: 'BOWL', 'All-Rounder': 'AR', Wicketkeeper: 'WK' };
export const RoleTag = ({ p }) => <span className="chip font-mono" title={p.role + (p.style ? ` (${p.style})` : '')}>{ROLE_SHORT[p.role]}{p.style ? <span className="text-fg-3">·{p.style === 'Spin' ? 'SPN' : 'PCE'}</span> : null}</span>;

export function Modal({ open, onClose, title, children, wide = false, footer }) {
  useEffect(() => {
    if (!open) return;
    const k = (e) => e.key === 'Escape' && onClose?.();
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 animate-fade sm:items-center sm:p-6" onClick={onClose}>
      <div
        className={`panel flex max-h-[92dvh] w-full flex-col overflow-hidden rounded-b-none animate-rise sm:rounded-b-2xl ${wide ? 'sm:max-w-4xl' : 'sm:max-w-lg'}`}
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-modal="true"
      >
        <div className="flex h-14 shrink-0 items-center justify-between border-b border-line px-5">
          <h2 className="text-[15px] font-medium">{title}</h2>
          {onClose && <button className="btn btn-ghost btn-sm -mr-2 px-2" onClick={onClose} aria-label="Close"><LuX size={18} /></button>}
        </div>
        <div className="scroll-y flex-1 p-5">{children}</div>
        {footer && <div className="shrink-0 border-t border-line p-4 safe-bottom">{footer}</div>}
      </div>
    </div>
  );
}

export function Seg({ value, options, onChange, disabled }) {
  return (
    <div className="inline-flex rounded-[10px] border border-line bg-ink-900 p-1">
      {options.map(([v, label]) => (
        <button key={String(v)} disabled={disabled} onClick={() => onChange(v)}
          className={`h-8 rounded-md px-3 text-[13px] transition-colors ${value === v ? 'bg-ink-700 text-fg shadow-[inset_0_1px_0_rgb(255_255_255/0.08)]' : 'text-fg-2 hover:text-fg'}`}>
          {label}
        </button>
      ))}
    </div>
  );
}

export function Toggle({ checked, onChange, disabled, label }) {
  return (
    <button role="switch" aria-checked={checked} aria-label={label} disabled={disabled} onClick={() => onChange(!checked)}
      className={`relative h-6 w-10 shrink-0 rounded-full border transition-colors disabled:opacity-50 ${checked ? 'border-transparent bg-brass' : 'border-line-2 bg-ink-800'}`}>
      <span className={`absolute top-0.5 size-[18px] rounded-full transition-transform ${checked ? 'translate-x-[18px] bg-ink-900' : 'translate-x-0.5 bg-fg-2'}`} />
    </button>
  );
}

export function Bar({ value, max, color = 'var(--color-fg-2)', h = 4 }) {
  const pct = Math.max(0, Math.min(100, (value / Math.max(1, max)) * 100));
  return <div className="w-full overflow-hidden rounded-full bg-ink-800" style={{ height: h }}><div className="h-full rounded-full transition-[width] duration-500" style={{ width: pct + '%', background: color }} /></div>;
}

/* Toasts */
const ToastCtx = createContext(() => {});
export const useToast = () => useContext(ToastCtx);
export function ToastHost({ children }) {
  const [items, setItems] = useState([]);
  const push = (text) => {
    const id = Math.random();
    setItems((x) => [...x.slice(-2), { id, text }]);
    setTimeout(() => setItems((x) => x.filter((i) => i.id !== id)), 2600);
  };
  return (
    <ToastCtx.Provider value={push}>
      {children}
      <div className="pointer-events-none fixed inset-x-0 top-3 z-[60] flex flex-col items-center gap-2 px-4">
        {items.map((i) => <div key={i.id} className="raised rounded-[10px] px-4 py-2 text-[13px] shadow-lg animate-rise">{i.text}</div>)}
      </div>
    </ToastCtx.Provider>
  );
}

export function Empty({ children }) {
  return <div className="py-8 text-center text-[13px] text-fg-3">{children}</div>;
}

export function useNow(ms = 200) {
  const [t, setT] = useState(now());
  useEffect(() => { const i = setInterval(() => setT(now()), ms); return () => clearInterval(i); }, [ms]);
  return t;
}

export function Logo({ small }) {
  return (
    <span className="inline-flex items-center gap-2">
      <svg width={small ? 20 : 24} height={small ? 20 : 24} viewBox="0 0 24 24" aria-hidden>
        <circle cx="12" cy="9.5" r="7.5" fill="var(--color-brass)" />
        <rect x="10.5" y="15.5" width="3" height="7" rx="1.2" fill="var(--color-brass)" />
        <text x="12" y="12.6" textAnchor="middle" fontSize="8.5" fontWeight="700" fontFamily="Inter, sans-serif" fill="#17120a">W</text>
      </svg>
      <span className={`${small ? 'text-[15px]' : 'text-[17px]'} font-semibold tracking-tight`}>A Walleh Auction</span>
    </span>
  );
}
